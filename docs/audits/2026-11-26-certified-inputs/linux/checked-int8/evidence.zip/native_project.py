"""Replay a compact, text-only projection of the hosted signed-INT8 JIT records.

verify() checks the frozen public record, site offsets and representative decoded
operands. With the original official ZIP it also decodes every instruction listed
by the host and compares it with the bytes of its recorded generated kernel.
"""
import hashlib
import json
import re
import struct
import zipfile
from functools import lru_cache
from itertools import groupby
from pathlib import Path, PurePosixPath


FILE = "jit-projection.json"
RELEASE = "6a9c6a696903926b83caf19364b4d19b23f8f2f6"
RUN = 45792579553
ARCHIVES = {
    "aarch64": (15103644670, "d03a308d69770c7dd30b01b4c6d7c5a5e7c29b0049d5f79b3be4a630176709ab"),
    "x86_64": (15104162186, "f4044fb5a5294ff6b58bd2df6882ae65f1c5eb3996b530819e28e1e71fb3a9b7"),
}
LOCKED = {
    "aarch64": "c8ede10f4b9744338e13e0d217d670c594fcac1c8adc622d439e01e2079185fa",
    "x86_64": "c4ad3875a92f4e96e3915ce65178384e434ee927842b1121f11016d074de0378",
}
FAMILIES = ("square4096", "fresh3584", "heldout", "optdigits", "optdigits-images")
MODES = ("checked", "raw")
OPCODE = {"aarch64": "smmla", "x86_64": "tdpbssd"}


def require(condition, message):
    if not condition:
        raise ValueError("INT8 kernel evidence: " + message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def filename(family, mode, rel):
    require(family in FAMILIES and mode in MODES, "unknown geometry or provider")
    path = PurePosixPath(rel)
    require(path.parent == PurePosixPath("jit", family + "-" + mode) and
            re.fullmatch(r"dnnl_dump_cpu_[A-Za-z0-9_.]+\.bin", path.name) and
            ("gemm" in path.name or "matmul" in path.name), "unexpected JIT member " + rel)
    return path.as_posix()


def encode(arch, regs):
    require(isinstance(regs, list) and len(regs) == 3 and all(type(x) is int for x in regs), "invalid operands")
    dest, first, second = regs
    if arch == "aarch64":
        require(all(0 <= x < 32 for x in regs), "invalid SVE register")
        word = 0x45009800 | (second << 16) | (first << 5) | dest
        return struct.pack("<I", word)
    require(all(0 <= x < 8 for x in regs), "invalid AMX register")
    return bytes((0xc4, 0xe2, 0x43 | ((7 - second) << 3), 0x5e, 0xc0 | (dest << 3) | first))


def decode_line(arch, line):
    if arch == "aarch64":
        match = re.fullmatch(r"\s*([0-9a-fA-F]+):\s*([0-9a-fA-F]{8})\s+smmla\s+z(\d+)\.s,\s*z(\d+)\.b,\s*z(\d+)\.b\s*", line)
        require(match, "malformed SVE signed multiply disassembly")
        instruction = struct.pack("<I", int(match[2], 16))
    else:
        match = re.fullmatch(r"\s*([0-9a-fA-F]+):\s*((?:[0-9a-fA-F]{2}\s+){5})tdpbssd\s+tmm([0-7]),\s*tmm([0-7]),\s*tmm([0-7])\s*", line)
        require(match, "malformed AMX signed multiply disassembly")
        instruction = bytes.fromhex(match[2])
    regs = [int(x) for x in match.groups()[2:]]
    require(encode(arch, regs) == instruction, "disassembly disagrees with ISA opcode and operands")
    return int(match[1], 16), regs, instruction


def offsets_hash(offsets):
    return sha(b"".join(struct.pack("<I", at) for at in offsets))


def offsets_rle(offsets):
    gaps = [b-a for a,b in zip(offsets, offsets[1:])]
    return [[gap, sum(1 for _ in group)] for gap, group in groupby(gaps)]


def summarize(arch, binary, listing):
    decoded = [decode_line(arch, line) for line in listing.decode().splitlines()]
    require(decoded, "empty instruction listing")
    offsets = [row[0] for row in decoded]
    width = 4 if arch == "aarch64" else 5
    require(all(b >= a + width for a,b in zip(offsets, offsets[1:])), "overlapping or unsorted instruction sites")
    for at, _, instruction in decoded:
        require((arch != "aarch64" or at % 4 == 0) and binary[at:at+width] == instruction, "opcode differs from actual kernel bytes")
    samples = []
    for i in sorted({0, len(decoded)//2, len(decoded)-1}):
        at, regs, instruction = decoded[i]
        samples.append({"index": i, "offset": at, "registers": regs, "instruction_sha256": sha(instruction)})
    return {"binary_sha256": sha(binary), "binary_size": len(binary), "disasm_sha256": sha(listing),
            "sites": len(decoded), "opcode": OPCODE[arch], "first_offset": offsets[0],
            "offset_gaps_rle": offsets_rle(offsets), "offsets_u32le_sha256": offsets_hash(offsets), "samples": samples}


def document(arch, read, records):
    bindings, objects = {}, {}
    for family in FAMILIES:
        for mode in MODES:
            receipt = json.loads(read(f"proof/{family}-{mode}-actual.json"))
            require(receipt["architecture"] == arch and receipt["family"] == family and receipt["method"] == mode,
                    "diagnostic receipt under incorrect architecture/geometry")
            for kernel in receipt["jit_kernels"]:
                path = filename(family, mode, kernel["path"])
                require(path not in bindings, "duplicate recorded JIT kernel")
                binary_name = "proof/" + path
                listing_name = binary_name + ".opcodes"
                binary, listing = read(binary_name), read(listing_name)
                s = summarize(arch, binary, listing)
                require((s["binary_sha256"], s["sites"], s["opcode"]) ==
                        (kernel["sha256"], kernel["sites"], kernel["operation"]), "kernel disagrees with diagnostic receipt")
                if records is not None:
                    for name, digest in ((binary_name,s["binary_sha256"]), (listing_name,s["disasm_sha256"])):
                        r = records[name]
                        require(r["path"] == name and r["source_sha256"] == r["projection_sha256"] == digest, "sealed member mismatch")
                obj = s["binary_sha256"] + "." + s["disasm_sha256"]
                require(obj not in objects or objects[obj] == s, "conflicting records for the same bytes")
                objects[obj] = s
                bindings[path] = obj
    if records is not None:
        expected = {"proof/" + p + ext for p in bindings for ext in ("", ".opcodes")}
        require({n for n in records if n.startswith("proof/jit/")} == expected, "unbound or missing sealed JIT member")
    asset, digest = ARCHIVES[arch]
    return {"version": 1, "benchmark": RELEASE, "run": RUN, "architecture": arch,
            "asset_id": asset, "archive_sha256": digest, "objects": objects, "bindings": bindings}


def create(sealed_host_raw, destination_dir, archive_metadata=None):
    """Write jit-projection.json using an extracted sealed kit's HOST/raw directory."""
    source = Path(sealed_host_raw)
    proof = source / "native-proof"
    records = json.loads((proof / "membership.json").read_bytes())
    first = json.loads((proof / "proof/square4096-checked-actual.json").read_bytes())
    arch = first["architecture"]
    if archive_metadata is None:
        archive_metadata = source.parent / "provenance.json"
    if not isinstance(archive_metadata, dict):
        archive_metadata = json.loads(Path(archive_metadata).read_bytes())
    require(arch in ARCHIVES and (archive_metadata["artifact_id"], archive_metadata["artifact_sha256"]) == ARCHIVES[arch]
            and archive_metadata["run"] == RUN and archive_metadata["source_sha"] == RELEASE, "original artifact receipt")
    data = canonical(document(arch, lambda n: (proof/n).read_bytes(), records))
    require(sha(data) == LOCKED[arch], "projection disagrees with frozen artifact")
    out = Path(destination_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out/FILE).write_bytes(data)
    return out/FILE


@lru_cache(maxsize=2)
def _verified(data):
    rec = json.loads(data)
    arch = rec["architecture"]
    require(arch in ARCHIVES and rec["version"] == 1 and rec["run"] == RUN and rec["benchmark"] == RELEASE and
            (rec["asset_id"], rec["archive_sha256"]) == ARCHIVES[arch] and sha(data) == LOCKED[arch], "unregistered public record")
    require(set(rec["objects"]) == set(rec["bindings"].values()), "orphan or missing object summaries")
    width = 4 if arch == "aarch64" else 5
    for path, key in rec["bindings"].items():
        family, mode = PurePosixPath(path).parent.name.rsplit("-", 1)
        filename(family, mode, path)
    for obj, s in rec["objects"].items():
        require(obj == s["binary_sha256"]+"."+s["disasm_sha256"] and s["opcode"] == OPCODE[arch], "wrong kernel identity")
        offsets = [s["first_offset"]]
        for delta, count in s["offset_gaps_rle"]:
            require(type(delta) is int and type(count) is int and delta >= width and 0 < count < 100000 and len(offsets)+count <= s["sites"], "invalid offset runs")
            for _ in range(count):
                offsets.append(offsets[-1]+delta)
        require(len(offsets) == s["sites"] and offsets[0] >= 0 and offsets[-1]+width <= s["binary_size"] and
                (arch != "aarch64" or all(v%4 == 0 for v in offsets)) and offsets_hash(offsets) == s["offsets_u32le_sha256"], "site offsets or digest")
        samples = s["samples"]
        require([v["index"] for v in samples] == sorted({0, len(offsets)//2, len(offsets)-1}), "representative sample positions")
        for v in samples:
            require(offsets[v["index"]] == v["offset"] and sha(encode(arch,v["registers"])) == v["instruction_sha256"], "decoded sample/offset")
    return rec


def verify(projection_dir, original_zip=None):
    """Validate the frozen text projection and optionally reconstruct it from GitHub's original ZIP."""
    data = (Path(projection_dir)/FILE).read_bytes()
    doc = _verified(data)
    if original_zip is not None:
        archive_path = Path(original_zip)
        with archive_path.open("rb") as stream:
            digest = hashlib.sha256()
            for chunk in iter(lambda: stream.read(1048576), b""):
                digest.update(chunk)
        require(digest.hexdigest() == doc["archive_sha256"], "official ZIP SHA-256")
        with zipfile.ZipFile(archive_path) as archive:
            require(len(archive.namelist()) == len(set(archive.namelist())), "duplicate ZIP member")
            restored = document(doc["architecture"], archive.read, None)
        require(canonical(restored) == data, "regenerated projection differs")
    return {"architecture": doc["architecture"], "kernel_bindings": len(doc["bindings"]),
            "unique_kernel_listings": len(doc["objects"]), "sites_across_bindings": sum(doc["objects"][k]["sites"] for k in doc["bindings"].values()),
            "official_zip_rechecked": original_zip is not None}


def lookup(projection_dir, family, mode, kernel_relpath):
    """Return the digest, signed opcode and site count for one actual raw or checked geometry."""
    rec = _verified((Path(projection_dir)/FILE).read_bytes())
    path = filename(family, mode, str(kernel_relpath))
    found = rec["objects"][rec["bindings"][path]]
    return {"sha256":found["binary_sha256"], "sites":found["sites"], "opcode":found["opcode"],
            "binary_original_sha256":found["binary_sha256"], "disasm_original_sha256":found["disasm_sha256"]}
