"""Independent replay of public-call timing, precision, dispatch and fallback admission."""
from collections import Counter,defaultdict
import csv
import json
import hashlib
import math
from statistics import median
import re

SEEDS=(2341279043,916583729)
HEX=re.compile(r"^[0-9a-f]{64}$")
def ensure(ok,msg):
    if not ok:raise ValueError(str(msg))
def load(p):return json.loads(p.read_bytes())
def readcsv(p):
    with p.open() as f:return list(csv.DictReader(f))

def shape_decision(p,method,proof,trace,stage):
    kind=p["spec"]; band=kind not in ("early","late")
    if method=="s8-dispatch":
        if not proof["checked_probe_passed"]:return False
        mode,reason,scanned,amax,bmax,plans,terms,back,native,impl=trace["S8_ROUTE"][stage]
        status=tuple(map(int,(mode,scanned,amax,bmax,plans,terms,back,native)))
        total=p["k"]*(p["m"]+p["n"])
        cap={"exact":63,"early":63,"late":63,"optdigits":16,"optdigits-images":1}[kind]
        if p["k"]<=128:
            return status==(2,0,-1,-1,0,0,1,0) and reason=="depth-shallow"
        if int(mode)==3:
            return not proof["checked_int8_native"] and reason=="backend-unavailable" and status[4:]==(0,0,1,0) and (
                status[1:4]==(0,-1,-1) or (band and status[1:4]==(total,cap,cap)))
        if kind=="early":return status==(2,min(p["k"],64),-1,-1,0,0,1,0) and reason=="integer-domain"
        if kind=="late":return status==(2,total,cap,-1,0,0,1,0) and reason=="integer-domain"
        return proof["checked_int8_native"] and status==(1,total,cap,cap,1,1,0,1) and p["k"]*cap*cap<=2**24 and reason=="native-exact" and impl==proof["int8_implementation"] and bool(impl)
    if method=="exact-dispatch":
        r,count=trace["ROUTE"][stage],p["k"]*(p["m"]+p["n"])
        mode,reason,scanned,amax,bmax,fast,back,work,native,text=r
        vals=tuple(map(int,(mode,scanned,amax,bmax,fast,back,work,native)))
        if not proof["eligible"]:
            return vals==(3,0,-1,-1,0,1,0,0) and reason=="native-disabled"
        if kind=="early":return vals==(2,min(p["k"],64),-1,-1,0,1,0,0) and reason=="integer-domain"
        if kind=="late":return vals==(2,count,63,-1,0,1,0,0) and reason=="integer-domain"
        mx={"exact":63,"optdigits":16,"optdigits-images":1}[kind]
        return vals==(1,count,mx,mx,1,0,1,1) and p["k"]*mx*mx<=2**24 and reason=="native-exact" and text==proof["implementation"] and bool(text)
    if method=="raw-bf16":
        return trace["BF16"][stage]==["1","1","1","1",proof["implementation"]] and proof["eligible"]
    if method=="onednn-int8":
        terms,impl=trace["INT8"][stage]
        return band and proof["int8_eligible"] and terms=="1" and impl==proof["int8_implementation"] and "ref" not in impl.lower()
    if method=="bitset-popcount":
        return kind=="optdigits-images" and trace["BINARY"][stage]==[str((p["k"]+63)//64)]
    if method.startswith("onednn-"):
        impl,made,cached=trace["DNN"][stage]
        retained=method.endswith("cached-plan")
        return bool(impl) and "ref" not in impl.lower() and int(cached)==int(retained) and int(made)==(1 if retained or stage=="FIRST" else 2)
    return True

def assess(root,arch,source,inputs):
    raw=root/"raw"; me=load(raw/"measurement.json"); host=load(root/"provenance.json"); official=load(raw/"score.json")
    adm=load(raw/"admissions.json")
    expected=readcsv(source/"s8/panel.csv"); panel=[]
    for r in expected:
        panel.append({k:v if k in ("family","spec") else int(v) for k,v in r.items()})
    ensure(panel==me["panel"] and tuple(me["seeds"])==SEEDS,"shape, physical stride or seed schedule")
    ensure(me["cpu"]==int((raw/"cpu.txt").read_text()) and me["page_bytes"]>=4096 and HEX.fullmatch(me["worker_sha256"]),"worker CPU or recorder identity")
    ensure(me["panel_sha256"]==hashlib.sha256((source/"s8/panel.csv").read_bytes()).hexdigest(),"source panel digest")
    methods=me["methods"]; names=list(methods)
    base=["s8-dispatch","exact-dispatch","raw-bf16","fp32-policy","cob-standalone","openblas",("mkl" if arch=="x86_64" else "armpl"),"blasfeo","fastmmw-1536","fastmmw-768"]
    if arch=="x86_64":base+=["mkl-jit","aocl","release-mkl-aligned-two"]
    ensure(names==base+["onednn-oneshot","onednn-cached-plan","onednn-int8","bitset-popcount"],"registered method roster order")
    records=[json.loads(x) for x in (raw/"observations.jsonl").read_text().splitlines()]
    cursor=0; coverage=Counter(); failures={}; rng_inputs={}; calls=Counter();checks_by_method=Counter()
    for i,p in enumerate(panel):
        f=p["family"];s=p["spec"];cert=s not in ("early","late");area=p["m"]*p["n"]
        a=adm[f]; binding=me["bindings"][f]
        ensure(binding["native"]==a["eligible"] and binding["implementation"]==a["implementation"] and binding["int8_eligible"]==a["int8_eligible"] and
               binding["checked_int8_native"]==a["checked_int8_native"] and binding["checked_probe_passed"]==a["checked_probe_passed"] and binding["fallback_method"]==a["fallback_method"] and binding["fallback_sha256"]==methods["fp32-policy"]["plugin_sha256"],"admission binding")
        declared=("release-mkl-aligned-two" if arch=="x86_64" else "fastmmw-1536") if f=="square4096" else ("mkl-jit" if arch=="x86_64" else "armpl")
        ensure(a["fallback_method"]==declared,"unregistered backing implementation")
        local=official["cases"][f];active=[n for n in names if n not in me["skips"][f]]
        for n in names:
            ok=(methods[n]["plugin_sha256"] is not None and (n!="raw-bf16" or a["eligible"]) and
                (n!="onednn-int8" or (cert and a["int8_eligible"])) and (n!="bitset-popcount" or s=="optdigits-images"))
            ensure(ok==(n in active),"unexplained inclusion or omission "+f+"/"+n)
        logs=defaultdict(list)
        for b,seed in enumerate(SEEDS):
            g=me["goldens"][f][str(seed)];vector=inputs[f][str(seed)]
            ensure(g["outputs"]==area and g["spot_checks"]==32 and g["inputs"]==vector["inputs"] and HEX.fullmatch(g["signed_sha256"]) and HEX.fullmatch(g["weight_sha256"]),"independent fixture/oracle digest "+f)
            if "signed_sha256" in vector:
                ensure(g["signed_sha256"]==vector["signed_sha256"] and g["weight_sha256"]==vector["weight_sha256"],"independent full real corpus product differs")
            rng_inputs[f,str(seed)]=(g["signed_sha256"],g["weight_sha256"])
            for rnd in (1,2,3):
                # Independently reconstruct the chronological order, including the block inversion.
                rotate=(i+3*(rnd-1)+5*b)%len(active)
                line=active[rotate:]+active[:rotate]
                if b:line.reverse()
                for pos,n in enumerate(line):
                    row=records[cursor];cursor+=1
                    ensure([row[k] for k in ("family","method","seed","round","position")]==[f,n,seed,rnd,pos],"chronological schedule mismatch")
                    logs[n].append(row)
            coverage["goldens"]+=1
        guards=((p["cr"]+p["m"]+2)*p["ldc"]*4+me["page_bytes"]-1)//me["page_bytes"]*(me["page_bytes"]//4)-area
        by={}
        for n,rs in logs.items():
            stable=True; valid=True;exact=True;bad_reason=set(); seen={};times={"FIRST":[],"WARM":[]}
            for j,row in enumerate(rs):
                if "failure" in row:
                    stable=False;bad_reason.add(row["failure"]);coverage["failed_invocations"]+=1;continue
                ensure(row["inputs"]==inputs[f][str(row["seed"])]["inputs"],"worker/golden logical identity")
                for stage in ("FIRST","WARM"):
                    v=row["stages"][stage]
                    for field in ("seconds","cpu_seconds"):
                        ensure(math.isfinite(v[field]) and v[field]>0,"invalid timer")
                    numeric = all(v[q]==0 for q in ("nonfinite","over_abs","over_gamma")) and v["max_abs"] is not None and v["max_abs"]<=0.002 and v["max_rho"] is not None and v["max_rho"]<=p["k"]/(2**24-p["k"])
                    valid &= numeric
                    exact &= v["not_exact"]==0
                    # Every structural rejection remains a measured observation in the archive.
                    try:route_ok=shape_decision(p,n,a,row.get("traces",{}),stage)
                    except (KeyError,ValueError,TypeError,IndexError):route_ok=False
                    good=(v["threads"]==1 and v["cpu"]==me["cpu"] and v["checked"]==area and v["guards"]==guards and v["guard_changes"]==0 and
                          re.fullmatch(r"[0-9a-f]{64}",v["output_sha256"]) and v["output_sha256"]==seen.setdefault(row["seed"],v["output_sha256"]) and route_ok)
                    bf16_fallback=n=="exact-dispatch" and (not cert or not a["eligible"])
                    s8_receipt=row.get("traces",{}).get("S8_ROUTE",{}).get(stage,[])
                    s8_fallback=n=="s8-dispatch" and len(s8_receipt)==10 and s8_receipt[0]!="1"
                    if bf16_fallback or s8_fallback:
                        backing=logs["fp32-policy"][j]
                        good=good and "stages" in backing and v["output_sha256"]==backing["stages"][stage]["output_sha256"]
                        if good:coverage[n+"_fallback_bit_identical"]+=1
                    if n=="fp32-policy" and declared in logs and "stages" in logs[declared][j]:
                        coverage["backing_vs_configured_provider_checks"]+=1
                        direct_hash=logs[declared][j]["stages"][stage]["output_sha256"]
                        coverage["backing_vs_configured_provider_identical"]+=int(v["output_sha256"]==direct_hash)
                    if s.startswith("optdigits") and v["not_exact"]==0:
                        good=good and v["output_sha256"]==inputs[f][str(row["seed"])]["output_sha256"]
                    if not good: stable=False;bad_reason.add("guard, dispatch, CPU or per-input output equality")
                    if not numeric:bad_reason.add("FP64 accuracy")
                    if v["not_exact"]:bad_reason.add("FP64 result differs")
                    coverage["timed_calls"]+=1;coverage["checked_output_values"]+=v["checked"];coverage["guard_values"]+=v["guards"]
                    coverage["nonfinite"]+=v["nonfinite"];coverage["guard_changes"]+=v["guard_changes"]
                    if n=="s8-dispatch":calls[s8_receipt[1] if len(s8_receipt)==10 else "unreported"]+=1
                    checks_by_method[n]+=v["checked"]
                    times[stage].append(v["seconds"])
            admissible=stable and valid
            ensure((n in local["structural"])==stable and (n in local["qualified_numerical"])==admissible and
                   (n in local["qualified_exact"])==(admissible and exact),"independent admission differs from frozen scorer "+f+"/"+n)
            if bad_reason:failures[f+"/"+n]=sorted(bad_reason)
            if stable:
                for stage,arr in times.items():
                    ensure(arr==local["evidence"][n]["times_s"][stage] and median(arr)*1000==local["evidence"][n]["medians_ms"][stage],"absolute medians")
                by[n]=times
        for stage,comp in local["candidate_comparisons"].items():
            candidate=by["s8-dispatch"][stage]
            for peer,out in comp["peers"].items():
                other=by[peer][stage]; ratios=[o/c for o,c in zip(other,candidate)]
                wins=sum(a>b for a,b in zip(other,candidate)); md=median(ratios)
                ensure(out["paired_ratios"]==ratios and out["paired_median"]==md and out["raw_median_ratio"]==median(other)/median(candidate) and
                       out["seed_medians"]==[median(ratios[:3]),median(ratios[3:])] and out["wins"]==wins and
                       out["passes"]==(wins>=5 and md>1.02),"independent paired ratio or gate differs")
            admitted=local["qualified_numerical"];exact=local["qualified_exact"]
            ordinary=[n for n in admitted if methods[n]["role"] in ("fp32-backing","standalone","independent-fp32","independent-retained","release-vendor-assisted")]
            external=[n for n in ordinary if methods[n]["role"] in ("independent-fp32","independent-retained")]
            domain=cert and 128<p["k"]<=4096
            native_s8=domain and a["checked_int8_native"]
            full=[n for n in admitted if n in ordinary or n in exact or
                  (n=="s8-dispatch" and not native_s8) or (n=="exact-dispatch" and (not cert or not a["eligible"]))]
            pools=dict(fp32_oneshot=[n for n in ordinary if methods[n]["role"]!="independent-retained"],fp32_any=ordinary,
                       fp32_exact=[n for n in ordinary if n in exact],
                       fp32_exact_oneshot=[n for n in ordinary if n in exact and methods[n]["role"]!="independent-retained"],
                       independent_fp32_any=external,independent_fp32_oneshot=[n for n in external if methods[n]["role"]!="independent-retained"],
                       integer_specialists=[n for n in exact if methods[n]["role"] in ("integer-specialist","binary-specialist")],
                       all_qualified=full,checked_policies=[n for n in full if n in ("fp32-policy","s8-dispatch","exact-dispatch")])
            for tier,pool in pools.items():
                leader=min(pool,key=lambda n:median(by[n][stage]),default=None)
                ensure(leader==local["leaders"][stage][tier],"independent raw-median field ranking "+tier)
                challengers=[n for n in pool if n!="s8-dispatch"]
                rival=min(challengers,key=lambda n:median(by[n][stage]),default=None)
                ensure(rival==comp["strongest"].get(tier,{}).get("peer"),"independent fastest qualified rival "+tier)
            ensure(local["checked_native_domain"]==domain and local["expected_native"]==native_s8,"native domain boundary")
    ensure(cursor==len(records)==official["observations"],"missing or extra observations")
    fresh=official["cases"]["fresh3584"]
    opponent=fresh["candidate_comparisons"].get("WARM",{}).get("strongest",{}).get("fp32_any")
    native=fresh["primary_status"]=="verified-native" and "s8-dispatch" in fresh["qualified_exact"]
    rule=bool(opponent and native and min(opponent["paired_median"],opponent["raw_median_ratio"])>=2 and opponent["wins"]>=5)
    ensure(official["fresh_large_effect"]==dict(qualified=rule,exact_native=native,opponent=opponent),"fresh square 2x protocol rule")
    return dict(host=host["model"],coverage=dict(coverage,observations=cursor),exclusions=failures,dispatch_counts=dict(calls),
                checked_by_method=dict(checks_by_method),goldens={f+"_"+s:list(v) for (f,s),v in rng_inputs.items()})
