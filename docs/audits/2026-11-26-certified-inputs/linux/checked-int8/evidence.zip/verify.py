"""Verify the portable certified-input benchmark without native hardware or a network connection."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
from zipfile import ZipFile

from numerical import assess, ensure, load
import native_evidence

RUN=45792579553
REV="6a9c6a696903926b83caf19364b4d19b23f8f2f6"
BRANCH="bench/certified-inputs"
RELEASE="e4b7ce19cdf49f9175c86d3e91ea8d3a756eae9b"
ARCHES=("x86_64","aarch64")

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(root):
    files=sorted(p for p in root.rglob("*") if p.is_file() and p.relative_to(root).as_posix()!="SHA256SUMS")
    return "".join(f"{digest(p)}  {p.relative_to(root).as_posix()}\n" for p in files)

def archive_receipt(root,archive=None):
    receipt=load(root/"provenance.json");members=load(root/"members.json");a=receipt["arch"]
    ensure(a==root.name and a in ARCHES and receipt["run"]==RUN and receipt["source_sha"]==receipt["benchmark_sha"]==REV and
           receipt["branch"]==BRANCH and receipt["job"]== "Checked signed INT8 on "+a and receipt["attempt"]>0 and
           receipt["artifact"]==f"checked-s8-{a}-{RUN}-{receipt['attempt']}" and receipt["zipped_crc_passed"] and receipt["artifact_id"]>0 and
           receipt["job_id"]>0 and receipt["status"] in ("success","failure"),"official receipt/run/commit/CPU mismatch")
    for n,e in members.items():
        p=root/"raw"/n
        ensure(Path(n).name==n and p.is_file() and digest(p)==e["sha256"],"public raw member changed "+n)
    if archive:
        ensure(digest(archive)==receipt["artifact_sha256"] and archive.stat().st_size==receipt["bytes"],"original zip digest/size")
        with ZipFile(archive) as z:
            names=[s.filename for s in z.infolist() if not s.is_dir()]
            ensure(z.testzip() is None and len(names)==len(set(names))==receipt["members"],"original zip CRC or duplicate entries")
            for n,e in members.items():
                ensure(z.read(e["member"])==(root/"raw"/n).read_bytes(),"changed original benchmark evidence "+n)
        native_evidence.verify_archive(root/"raw",archive)
    return receipt

def score_host(root,arch):
    host=root/arch;raw=host/"raw"
    native=native_evidence.verify(raw)
    if not (raw/"score.json").is_file():
        return dict(host=load(host/"provenance.json")["model"],state="incomplete",available=sorted(load(host/"members.json")),native=native)
    source=root/"source/exact"
    for f in ("panel.csv","protocol.md"):
        ensure((raw/f).read_bytes()==(source/"s8"/f).read_bytes(),"frozen panel or protocol changed")
    ensure((raw/"benchmark-sha.txt").read_text().strip()==REV and (raw/"release-sha.txt").read_text().strip()==RELEASE,"wrong native source")
    official=load(raw/"score.json")
    sys.path.insert(0,str(source/"driver"))
    import score
    trial=score.compute(load(raw/"measurement.json"),[json.loads(l) for l in (raw/"observations.jsonl").read_text().splitlines()])
    ensure(trial==official,"detailed frozen-score replay failed")
    with tempfile.TemporaryDirectory() as tmp:
        stage=Path(tmp);score.write_results(stage,trial)
        ensure((stage/"comparisons.csv").read_bytes()==(raw/"comparisons.csv").read_bytes(),"frozen comparison table changed")
    answer=assess(host,arch,source,load(root/"input-digests.json"));answer["native"]=native;answer["state"]="scored"
    return answer

def verify(root, archives):
    ensure(snapshot(root)==(root/"SHA256SUMS").read_text(),"package checksum or membership mismatch")
    source=load(root/"source.json")
    ensure(source["revision"]==REV and source["release"]==RELEASE,"source identity")
    for n,h in source["git_blobs"].items():
        b=(root/n).read_bytes()
        ensure(hashlib.sha1(f"blob {len(b)}\0".encode()+b).hexdigest()==h,"source Git blob changed "+n)
    verify_supplement(root)
    expected=None
    for arch in ARCHES:
        host=root/arch;archive_receipt(host,archives.get(arch))
        result=score_host(root,arch)
        ensure(result==load(host/"audit.json"),"independent qualification or timing replay differs")
        if result["state"]=="scored":
            if expected is None:expected=result["goldens"]
            else:ensure(expected==result["goldens"],"full signed/weight goldens differ between hosts")
    from render import render
    with tempfile.TemporaryDirectory() as tmp:
        path=Path(tmp)
        render(root,path/"README.md")
        for name in ("README.md","peer-comparisons.csv"):
            ensure((root/name).read_bytes()==(path/name).read_bytes(),"published table or Markdown differs from replay "+name)
    print("Verified both official host records, all present observations, source and corpus hashes, frozen and independent ranking replays.")

def verify_supplement(root):
    import re
    data=root/"supplementary";v=load(data/"verified.json")
    ensure(v["revision"]==REV and v["git_source_dir"]=="tools/world-rank/exact/s8" and "qemu" in v["local_environment"],"local record provenance")
    for name,sha in v["source_sha256"].items():
        ensure(Path(name).name==name and digest(root/"source/exact/s8"/name)==sha,"local test used a different source")
    w=v["precision_witness"]
    ensure(w["native_exact_output_per_cell"]==w["ordinary_callback_rounded_output_per_cell"]==2**24 and
           w["above_certificate_mathematical_value"]==2**24+1 and w["native_case_cells"]==w["above_certificate_case_cells"]==513,"exact accumulator boundary record")
    for name,summary in v["receipts"].items():
        p=data/name
        ensure(digest(p)==summary["sha256"],"local receipt digest "+name)
        lines=p.read_text().splitlines()
        tested={row.split()[0][5:]:dict(item.split("=",1) for item in row.split()) for row in lines[:-1]}
        end=re.fullmatch(r"PASS cases=(\d+) output_cells=(\d+) guards=(\d+) mode=(\w+)",lines[-1])
        ensure(end and int(end[1])==len(tested)==len(lines)-1==summary["cases"] and int(end[2])==summary["output_cells"]==513*len(tested) and int(end[3])==summary["guard_cells"]==239*len(tested) and end[4]==summary["mode"],"incomplete local correctness record")
        if summary["mode"] in ("positive","faults"):
            inside=tested["exact-two-to-24"];outside=tested["ordinary-rounds-two-to-24-plus-one"]
            ensure(inside["route"]=="1" and inside["fallback"]=="0" and outside["reason"]=="accumulator-bound" and outside["fallback"]=="1","local numerical boundary")
        if summary["mode"]=="faults":
            ensure(tested["after-wait"]["fallback"]=="1" and tested["execute"]["fallback"]=="1" and tested["successful-retry"]["route"]=="1","backend failure/retry")
        if summary["mode"] in ("blocked","missing"):
            ensure(tested["unavailable"]["route"]=="3" and tested["unavailable"]["fallback"]=="1","unavailable CPU/DSO")

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive-x86_64",type=Path);p.add_argument("--archive-aarch64",type=Path)
    a=p.parse_args();verify(Path(__file__).resolve().parent,{"x86_64":a.archive_x86_64,"aarch64":a.archive_aarch64})
