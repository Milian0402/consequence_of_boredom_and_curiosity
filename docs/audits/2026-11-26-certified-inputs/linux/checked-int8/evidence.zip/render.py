"""Render authenticated checked-S8 Linux SGEMM scores and all matched competitor observations."""
import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

ARCHES = ('x86_64', 'aarch64')
STAGES = ('FIRST', 'WARM')
S8_SEEDS = (2341279043, 916583729)
CANDIDATE, OLD = 's8-dispatch', 'exact-dispatch'
REPO = 'https://github.com/Milian0402/consequence_of_boredom_and_curiosity'
LABELS = {'square4096':'Signed 4096³', 'fresh3584':'Signed 3584³', 'heldout':'Signed rectangle',
          'early-reject':'First A + ½', 'late-reject':'Last B + ½', 'optdigits':'UCI feature counts',
          'optdigits-images':'UCI binary pixels'}
GROUPS = ('fp32_oneshot','fp32_any','fp32_exact_oneshot','fp32_exact','independent_fp32_oneshot',
          'independent_fp32_any','integer_specialists','checked_policies','all_qualified')


def read(path):
    return json.loads(path.read_text())


def load_host(root, arch):
    folder = root / arch
    raw = folder / 'raw'
    receipt = read(folder / 'provenance.json')
    audit = read(folder / 'audit.json')
    if receipt['arch'] != arch:
        raise ValueError('Wrong host receipt')
    h = dict(arch=arch, receipt=receipt, audit=audit, model=receipt.get('model') or arch, score=None)
    if not (raw/'score.json').is_file():
        return h
    score = read(raw/'score.json')
    if score.get('candidate_method') != CANDIDATE or score.get('seeds') != list(S8_SEEDS):
        raise ValueError('Expected scored checked S8 experiment with registered seeds')
    traces = defaultdict(Counter)
    with (raw/'observations.jsonl').open() as stream:
        for line in stream:
            r = json.loads(line)
            if r['method'] != CANDIDATE:
                continue
            for stage, t in r.get('traces', {}).get('S8_ROUTE', {}).items():
                traces[r['family'],stage][tuple(t)] += 1
    h.update(score=score, measurement=read(raw/'measurement.json'), traces=traces)
    return h


def safe(text):
    return ' '.join(str(text).split()).replace('|', '/').replace('<', '&lt;').replace('>', '&gt;')


def ms(value):
    return f'{value:,.3f}' if value is not None else '—'


def name(method):
    return f'`{method}`' if method else '—'


def table(body, headings, rows):
    body.extend(['', '| ' + ' | '.join(headings) + ' |', '| ' + ' | '.join(['---'] * len(headings)) + ' |'])
    body.extend('| ' + ' | '.join(str(x) for x in row) + ' |' for row in rows)


def med(case, method, stage):
    return case['evidence'].get(method, {}).get('medians_ms', {}).get(stage)


def comparison(case, stage, peer):
    return case['candidate_comparisons'].get(stage, {}).get('peers', {}).get(peer)


def strongest(case, stage, group):
    return case['candidate_comparisons'].get(stage, {}).get('strongest', {}).get(group)


def ratio(record):
    return f"{record['paired_median']:.3f}× ({record['wins']}/6)" if record else '—'


def vs_method(c, stage, peer):
    t = med(c, peer, stage)
    return '—' if t is None else f"{ms(t)} · {ratio(comparison(c, stage, peer))}"


def vs_field(c, stage, group):
    r = strongest(c, stage, group)
    if not r:
        p = c['leaders'][stage].get(group)
        return f"{name(p)} {ms(med(c,p,stage))} ms · no paired comparison" if p and p!=CANDIDATE else '—'
    return f"{name(r['peer'])} {ms(med(c,r['peer'],stage))} ms · {ratio(r)}"


def describe_host(host):
    receipt, score = host['receipt'], host['score']
    if score is None:
        return f"- **{safe(host['model'])}.** No completed score is available. [Hosted job]({receipt['job_url']})"
    native = [c for c in score['cases'].values() if c['primary_status']=='verified-native']
    gaps = score['primary_gaps']
    outcome = (f"All {len(score['cases'])} candidate fixture outcomes verified." if score['primary_complete'] else
               'Primary gaps were ' + ', '.join(f"{LABELS.get(f,f)} ({safe(status)})" for f,status in gaps.items()) + '.')
    if not native:
        count_note = 'No signed native candidate route qualified.'
    else:
        clauses = []
        for stage in STAGES:
            pairs = [strongest(c,stage,'fp32_oneshot') for c in native]
            eligible = [r for r in pairs if r]
            clauses.append(f"{sum(r['passes'] for r in eligible)}/{len(eligible)} {stage.lower()}")
        count_note = (f"On {len(native)} verified native fixtures, the candidate cleared the paired improvement "
                      f"rule against the fastest qualifying one-shot FP32 opponent on {' and '.join(clauses)} comparisons.")
    return f"- **{safe(host['model'])}.** {outcome} {count_note} [Hosted job]({receipt['job_url']})"


def fresh_results(lines, hosts):
    lines += ['', '### New 3584³ square', '',
              'The large-effect test compares the exact native signed result with the fastest numerically '
              'qualified ordinary FP32 method, including retained plans. Both the median of six warm ratios '
              'and the ratio of separate warm medians must reach 2.00×, with at least five strict wins.']
    rows = []
    for host in hosts:
        score = host['score']
        gate = score.get('fresh_large_effect') if score else None
        if not gate:
            rows.append([safe(host['model']), 'unscored', *['—']*6])
            continue
        c = score['cases']['fresh3584']
        r = gate.get('opponent')
        p = r['peer'] if r else None
        rows.append([safe(host['model']), 'passed' if gate['qualified'] else 'failed',
                     'yes' if gate['exact_native'] else 'no', ms(med(c,CANDIDATE,'WARM')),
                     f"{name(p)} {ms(med(c,p,'WARM'))}" if p else '—',
                     f"{r['raw_median_ratio']:.4f}×" if r else '—',
                     f"{r['paired_median']:.4f}×" if r else '—', f"{r['wins']}/6" if r else '—'])
    table(lines,['CPU','2× gate','Verified exact native','Checked S8 ms','Strongest FP32, ms',
                 'Ratio of medians','Paired median','Wins'],rows)


def direct_policies(lines, cases):
    lines.extend(['', '### Checked S8 versus the previous checked BF16 policy', '',
                  'Times are raw medians in milliseconds. Each ratio divides the previous policy’s time by the '
                  'S8 policy’s time on the same seed and round. Both policies keep their own fallback behavior.'])
    rows = []
    for f, c in cases.items():
        for stage in STAGES:
            r = comparison(c,stage,OLD)
            pairs = ', '.join(f'{x:.4f}' for x in r['paired_ratios']) if r else '—'
            rows.append([LABELS[f],stage.lower(),ms(med(c,CANDIDATE,stage)),ms(med(c,OLD,stage)),
                         ratio(r),pairs])
    table(lines,['Fixture','Call','Checked S8 ms','Checked BF16 ms','Median paired ratio (wins)','Six paired BF16/S8 ratios'],rows)


def field_tables(lines, cases):
    lines.extend(['', '### Qualified comparisons by field', '',
                  'Each entry gives the fastest other eligible method by raw median time, its milliseconds, '
                  'and its paired time ratio against checked S8. One-shot entries charge per-call setup. '
                  'The retained-inclusive fields also admit oneDNN’s cached plan.'])
    sections = (
        (('fp32_oneshot','One-shot FP32'),('fp32_any','FP32 incl. retained'),('fp32_exact_oneshot','Exact one-shot FP32'),('fp32_exact','Exact FP32 incl. retained')),
        (('independent_fp32_oneshot','Independent one-shot FP32'),('independent_fp32_any','Independent FP32 incl. retained'),('integer_specialists','Exact integer/binary specialist'),('checked_policies','Other checked/backing policy')),
    )
    for fields in sections:
        rows = []
        for f,c in cases.items():
            for stage in STAGES:
                rows.append([LABELS[f],stage.lower(),*[vs_field(c,stage,k) for k,_ in fields]])
        table(lines,['Fixture','Call',*[label for _,label in fields]],rows)
    lines.extend(['', '### Complete field and fixed controls', '',
                  'The full-field winner column includes checked S8 itself. The next column compares it with '
                  'the fastest eligible rival. Each fixed-control cell gives the peer’s milliseconds, paired '
                  'ratio and strict wins for checked S8. The binary specialist is eligible on the pixel fixture.'])
    rows = []
    for f,c in cases.items():
        for stage in STAGES:
            winner = c['leaders'][stage].get('all_qualified')
            rows.append([LABELS[f],stage.lower(),f"{name(winner)} {ms(med(c,winner,stage))}",
                         vs_field(c,stage,'all_qualified'),*[vs_method(c,stage,peer) for peer in
                             ('fp32-policy','cob-standalone','raw-bf16','onednn-int8','bitset-popcount')]])
    table(lines,['Fixture','Call','Whole-field winner, ms','Fastest other eligible peer','Backing FP32',
                 'Standalone COB','Unchecked BF16','oneDNN S8 specialist','Binary AND/popcount'],rows)


def dispatch(lines, h):
    cases, audit, traces = h['score']['cases'], h['audit'], h['traces']
    lines.extend(['', '### Runtime routes and numerical checks', '',
                  'The independent signed preflight tests the backend on the geometry. The public candidate '
                  'makes its own decision on each call. The table lists observed branch reasons, the number '
                  'of logical input elements inspected per call, and the signed native result expected by the '
                  'frozen scorer. A checked S8 fallback is compared bit-for-bit with the FP32 backing call.'])
    rows = []
    for f,c in cases.items():
        details = Counter()
        for s in STAGES:
            for rec, count in traces[f,s].items():
                _,reason,scanned,_,_,_,_,_,_,impl = rec
                details[(safe(reason),scanned,safe(impl) if reason=='native-exact' else '')] += count
        detail = ', '.join(f"{reason} ({int(scanned):,} inspected, {count} receipts)" +
                           (f" · {name(impl)}" if impl else '') for (reason,scanned,impl),count in details.items())
        e = c['evidence'].get(CANDIDATE, {})
        measured = CANDIDATE in c['structural']
        err = f"{e['inexact_values']:,} / {e['checked_values']:,}" if measured else '—'
        rows.append([LABELS[f], ' × '.join(map(str,c['dimensions'])), name(c['binding']['fallback_method']),
                     'yes' if c['binding']['checked_int8_native'] else 'no',
                     'passed' if c['binding']['checked_probe_passed'] else 'failed',
                     'yes' if c['expected_native'] else 'no',
                     c['primary_status'], detail or 'no trace', err,
                     f"{e['max_abs']:.7g}" if measured else '—'])
    table(lines,['Fixture','M × N × K','Backing FP32','Signed capability','Checked probe','Expected native product',
                 'Primary outcome','Observed public call','Inexact / checked outputs','Max absolute error'],rows)
    native = audit.get('native', {})
    rows = []
    for f, geo in native.get('geometries', {}).items():
        def witness(kind):
            p = geo.get(kind,{})
            if not p.get('eligible'):
                return 'Unavailable · '+safe(p.get('reason','no qualified receipt'))
            ops = ', '.join(name(x) for x in p.get('opcodes',[])) or 'no retained opcode witness'
            return f"{name(p['implementation'])} · {ops}"
        def signed_probe(kind):
            p = geo.get(kind,{})
            if 'native' not in p:
                return safe(p.get('unverified','no verified receipt'))
            if not p['full_output_and_guards']:
                return 'output or guard probe failed'
            if not p['signed_product']:
                return 'FP32 fallback'
            ops = sorted({r['opcode'] for r in p['kernel_bytes_checked']})
            return f"{name(p['implementation'])} · " + (
                ', '.join(name(op) for op in ops) + f" ({p['native_instruction_sites']} sites)"
                if p['native'] else 'no verified signed opcode')
        rows.append([LABELS.get(f,f),signed_probe('checked_s8'),signed_probe('raw_s8'),witness('int8'),witness('bf16')])
    if rows:
        lines.extend(['', 'The independent primitive probes report the following implementations and '
                      'arithmetic instruction evidence. Instruction names identify code in the retained '
                      'probe evidence. They do not count retired instructions in the timed workers.'])
        table(lines,['Independently probed geometry','Checked S8 operator','Signed specialist',
                     'oneDNN signed primitive','Raw BF16'],rows)
    products=h['measurement']['methods']
    table(lines,['Timed adapter', 'Binary SHA-256'],
          [[name(n),name(products[n]['plugin_sha256'])] for n in
           (CANDIDATE, OLD,'raw-bf16','onednn-int8','bitset-popcount','fp32-policy') if n in products])
    coverage = audit.get('coverage', {})
    if 'timed_calls' in coverage:
        lines.extend(['', f"The audit checked {coverage['checked_output_values']:,} logical output values "
                      f"and {coverage['guard_values']:,} padding or guard locations in {coverage['timed_calls']:,} "
                      f"timed result checks. It recorded {coverage.get('s8-dispatch_fallback_bit_identical',0)} "
                      'bit-identical S8-policy fallback comparisons.'])


def exclusions(lines, cases):
    groups = defaultdict(list)
    for f,c in cases.items():
        for n,why in c['skips'].items():
            groups[n,safe(why)].append(LABELS[f])
        for n,e in c['evidence'].items():
            if n not in c['structural']:
                why = ', '.join(map(safe,e['structural_issues'])) or 'incomplete observations'
            elif n not in c['qualified_numerical']:
                why = f"failed numerical checks on {e['failed_numerical_calls']}/12 calls"
            elif n not in c['qualified_exact']:
                why = 'numerically qualified, with deviations from the exact output'
            else:
                continue
            groups[n,why].append(LABELS[f])
    lines += ['', '### Qualification by method']
    if groups:
        table(lines,['Method','Outcome','Fixtures'],[[name(n),why,', '.join(fs)] for (n,why),fs in groups.items()])
    else:
        lines += ['', 'Every registered method produced every reference output exactly.']


def write_host(h):
    a,r,s = h['arch'],h['receipt'],h['score']
    lines = [f"## {safe(h['model'])}",'']
    if s is None:
        failed = [x['name'] for x in r.get('steps',[]) if x.get('conclusion')=='failure']
        notes = ' Failed job steps included ' + ', '.join(map(safe,failed)) + '.' if failed else ''
        lines += [f"No complete score was recorded for this host.{notes} "
                  f"[Job]({r['job_url']}) · [Artifact receipt]({a}/provenance.json) · [Available evidence]({a}/audit.json)",'']
        return lines
    lines += [f"Six fresh workers per active method and fixture produced {s['observations']:,} process observations "
              f"on logical CPU {h['measurement']['cpu']}. [Job]({r['job_url']}) · "
              f"[Raw timing records]({a}/raw/observations.jsonl) · [Independent audit]({a}/audit.json)"]
    direct_policies(lines,s['cases'])
    field_tables(lines,s['cases'])
    dispatch(lines,h)
    exclusions(lines,s['cases'])
    lines += ['', f"[Scored observations]({a}/raw/score.json) · [Field comparisons]({a}/raw/comparisons.csv) · "
              f"[Admission receipts]({a}/raw/admissions.json)",'']
    return lines


def save_peer_csv(path, hosts):
    headings = ['arch','model','candidate','family','spec','m','n','k','stage','primary_status','expected_native',
                'signed_preflight','checked_probe_passed','bf16_preflight','raw_int8_admitted','backing_method','peer','peer_role',
                'peer_structural','peer_numerical','peer_exact','peer_exclusion','candidate_ms','peer_ms',
                'raw_median_ratio','paired_median','wins','ties','passes','seed1_median','seed2_median']
    headings += [f'{g}_raw_leader' for g in GROUPS]
    for i in range(1,7):
        headings += [f'seed_{i}',f'round_{i}',f'candidate_ms_{i}',f'peer_ms_{i}',f'pair_{i}']
    with path.open('w', newline='',encoding='utf-8') as handle:
        writer = csv.DictWriter(handle,headings,lineterminator='\n')
        writer.writeheader()
        for h in hosts:
            if h['score'] is None:
                continue
            methods = h['measurement']['methods']
            for f,c in h['score']['cases'].items():
                for stage in STAGES:
                    for n,meta in methods.items():
                        if n==CANDIDATE:
                            continue
                        binding = c['binding']
                        p = comparison(c,stage,n)
                        e = c['evidence'].get(n,{})
                        why = c['skips'].get(n,'') or ', '.join(e.get('structural_issues',[]))
                        if not why and n not in c['qualified_numerical']:
                            why = 'failed numerical qualification'
                        row = dict(arch=h['arch'],model=h['model'],candidate=h['score']['candidate_method'],
                                   family=f,spec=c['spec'],**dict(zip(('m','n','k'),c['dimensions'])),stage=stage,
                                   primary_status=c['primary_status'],expected_native=int(c['expected_native']),
                                   signed_preflight=int(binding['checked_int8_native']),checked_probe_passed=int(binding['checked_probe_passed']),
                                   bf16_preflight=int(binding['native']),
                                   raw_int8_admitted=int(binding['int8_eligible']),backing_method=binding['fallback_method'],
                                   peer=n,peer_role=meta['role'],peer_structural=int(n in c['structural']),
                                   peer_numerical=int(n in c['qualified_numerical']),peer_exact=int(n in c['qualified_exact']),
                                   peer_exclusion=why,candidate_ms=med(c,CANDIDATE,stage),peer_ms=med(c,n,stage))
                        row.update({g+'_raw_leader':c['leaders'][stage].get(g) for g in GROUPS})
                        if p:
                            row.update({k:p[k] for k in ('raw_median_ratio','paired_median','wins','ties','passes')})
                            row['seed1_median'],row['seed2_median']=p['seed_medians']
                        for i in range(6):
                            j=i+1
                            row[f'seed_{j}']=S8_SEEDS[i//3]
                            row[f'round_{j}']=i%3+1
                            if p:
                                row[f'pair_{j}']=p['paired_ratios'][i]
                            for m,prefix in ((CANDIDATE,'candidate'),(n,'peer')):
                                arr=c['evidence'].get(m,{}).get('times_s',{}).get(stage,[])
                                if len(arr)==6:
                                    row[f'{prefix}_ms_{j}']=1000*arr[i]
                        writer.writerow(row)


def render(root, out):
    hosts=[load_host(root,a) for a in ARCHES]
    body=['# Checked signed INT8 for exact integer SGEMM', '',
          'The new dispatcher accepts ordinary row-major FP32 matrices. For a supported geometry and '
          'eligible input values it uses a signed INT8 product with 32-bit accumulation and writes FP32 '
          'results. Other calls go through the selected FP32 backing policy. The previous checked BF16 '
          'dispatcher was measured on the same inputs and in the same scheduling rounds.', '',
          *[describe_host(h) for h in hosts]]
    fresh_results(body,hosts)
    body.extend(['', '## What was measured', '',
          'The seven fixtures include signed 4096³ and 3584³ cubes, a cropped 1079 × 1553 × 1201 signed '
          'rectangle, and two copies of that rectangle with ½ added to the first A value or last B value. '
          'The UCI handwritten-digit fixtures multiply 1,797 test examples against 3,823 training examples '
          'at K = 64, and 1,797 against 1,934 binary images at K = 1,024. The K = 64 fixture exercises the '
          'new shape-only FP32 bypass for K ≤ 128. Both digit products come from one collection. '
          '[UCI dataset](https://doi.org/10.24432/C50P49) · [Frozen transformations and hashes](source/exact/fixtures/data/ATTRIBUTION.md)',
          '', 'The signed path checks input integrality, signed-byte range, and K × max|A| × max|B| ≤ 2²⁴. '
          'That last bound keeps the result and all partial integer sums exactly representable in FP32. '
          'The application decides from runtime CPU capability, input values and the actual oneDNN primitive. '
          'It requires AMX INT8 with usable tiles on x86 or SVE I8MM on Arm. Each accelerated call validates and packs '
          'current inputs, creates the signed primitive, and writes FP32 output. '
          'An independently recorded geometry-specific execution and opcode witness is used to verify native '
          'attribution. The raw BF16 comparator skips the application’s integer certificate. The signed '
          'oneDNN specialist checks its input and can abort on an unsupported call. It charges conversion, '
          'primitive construction, multiplication and output conversion. The popcount specialist packs the '
          'binary input in the timed operation. The earlier checked BF16 implementation is the one '
          'frozen in the [original experiment](https://github.com/Milian0402/consequence_of_boredom_and_curiosity/actions/runs/45788542642).',
          '', f'Within each fixture, the six ratios correspond to three matched rounds at seed {S8_SEEDS[0]} '
          f'and three at {S8_SEEDS[1]}. The real corpus operands remain fixed between blocks. Each worker '
          'times its first complete call after initialization. It checks and hashes the full output, '
          'poisons C again, and times the second complete call in the same process. “Warm” denotes that '
          'second call. Cache residency was unmeasured. Every time ratio '
          'divides opponent time by S8-policy time. A median paired ratio above one favors the new policy. '
          'The scoped improvement rule requires a median above 1.02× and at least five strict wins in six '
          'paired rounds. Each architecture has one native job.',
          '', 'Numerical admission checks every output for finiteness, absolute error ≤ 0.002 and error ≤ '
          'K/(2²⁴−K) times the sum of absolute products. Exact qualification additionally requires zero '
          'deviation. Exact native product, numerical FP32 fallback and numerical admission of an '
          'independent peer are recorded separately. [Every method, raw timing and paired ratio](peer-comparisons.csv)', ''])
    for h in hosts:
        body.extend(write_host(h))
    body += ['## Local correctness supplement','',
             'Separate Ubuntu 24.04 Docker checks on an Apple host used the frozen public entry and header. '
             'The Neoverse-N2 tests under QEMU produced exactly 2²⁴ across 513 outputs. For a true product of '
             '2²⁴ + 1 the certificate declined and ordinary FP32 rounded each of 513 outputs to 2²⁴. '
             'Injected failures during execution and after the wait left the caller’s output safe for fallback, '
             'and the subsequent retry succeeded. Arm and x86 transfer tests also exercised an unavailable backend. '
             'These are untimed correctness checks. [Test receipts](supplementary/verified.json) · '
             '[C API](source/exact/s8/checked-int8.h) · [Build and use](source/exact/s8/protocol.md)','']
    body += ['## Reproduction','','Run `python3 -B verify.py` at the evidence package root to replay '
             'the source, inputs, numerical qualification, rankings, report and CSV. Add '
             '`--archive-x86_64 PATH --archive-aarch64 PATH` to verify the source ZIP members.']
    for h in hosts:
        p=h['receipt']
        body += ['', f"{h['arch']} · [Job {p['job_id']}]({p['job_url']}) · "
                 f"artifact {p['artifact_id']}, SHA-256 `{p['artifact_sha256']}`."]
    source=read(root/'source.json')
    body.extend(['', f"[Frozen benchmark and protocol]({REPO}/tree/{source['revision']}/tools/world-rank/exact/s8) · "
                 f"[Timed COB release]({REPO}/tree/{source['release']})", ''])
    save_peer_csv(out.parent/'peer-comparisons.csv',hosts)
    out.write_text('\n'.join(body),encoding='utf-8')


if __name__=='__main__':
    cmd=argparse.ArgumentParser(description=__doc__)
    cmd.add_argument('package_root',type=Path)
    cmd.add_argument('output_md',type=Path)
    args=cmd.parse_args()
    render(args.package_root,args.output_md)
