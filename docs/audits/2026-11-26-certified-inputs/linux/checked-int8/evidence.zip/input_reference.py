"""Optional independent regeneration of all FP32 fixture hashes and both UCI products. Requires NumPy 2."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import numpy as np

SEEDS=(2341279043,916583729)
KNOWN={"optdigits":"ec47b13672085cc2096a990dd166c76e2e29843c7f79ea88d1d483db94b05db0",
       "optdigits-images":"eec353b47234bfe0fa3544331dc16aceee6a9b1ee3b7165b51e30fe565a9e825"}
def h(arr): return hashlib.sha256(arr).hexdigest()

def synthetic(size,seed,operand,mode):
    salt={"A":0x243f6a8885a308d3,"B":0x13198a2e03707344}[operand]
    digest=hashlib.sha256()
    first=-63 if operand=="A" else 63
    for off in range(0,size,262144):
        end=min(size,off+262144)
        idx=np.arange(off+1,end+1,dtype=np.uint64)
        x=idx*np.uint64(0x9e3779b97f4a7c15)+np.uint64(seed^salt)
        x=(x^(x>>np.uint64(30)))*np.uint64(0xbf58476d1ce4e5b9)
        x=(x^(x>>np.uint64(27)))*np.uint64(0x94d049bb133111eb)
        out=((x^(x>>np.uint64(31)))%127).astype("<f4")-63
        if off==0:out[0]=first+(.5 if mode=="early" and operand=="A" else 0)
        if end==size:out[-1]=-first+(.5 if mode=="late" and operand=="B" else 0)
        digest.update(out)
    return digest.hexdigest()

def corpus(src,mode,m,n,k):
    base="image" if mode=="optdigits-images" else "digits"
    a=np.fromfile(src/(base+"_A.u8"),dtype="u1").reshape(m,k)
    b=np.fromfile(src/(base+"_B.u8"),dtype="u1").reshape(k,n)
    fp=hashlib.sha256();double=hashlib.sha256()
    if base=="image":
        av=np.packbits(a,axis=1).view("u8")
        bv=np.ascontiguousarray(np.packbits(b.T,axis=1)).view("u8")
    else:
        av=a.astype("i4");bv=b.astype("i4")
    for i in range(0,m,32):
        dot=(np.bitwise_count(av[i:i+32,None,:]&bv[None,:,:]).sum(axis=2) if base=="image" else av[i:i+32]@bv)
        fp.update(dot.astype("<f4"));double.update(dot.astype("<f8"))
    if fp.hexdigest()!=KNOWN[mode]:raise ValueError("independent corpus product differs")
    return dict(inputs=[h(a.astype("<f4")),h(b.astype("<f4"))],output_sha256=fp.hexdigest(),signed_sha256=double.hexdigest(),weight_sha256=double.hexdigest())

def build(source):
    out={}
    with (source/"s8/panel.csv").open() as f:
        for row in csv.DictReader(f):
            fam=row["family"];mode=row["spec"];m,n,k=[int(row[x]) for x in "mnk"]
            if mode in KNOWN:
                run=corpus(source/"fixtures/data",mode,m,n,k)
                out[fam]={str(s):run for s in SEEDS}
            else:
                out[fam]={str(s):dict(inputs=[synthetic(m*k,s,"A",mode),synthetic(k*n,s,"B",mode)]) for s in SEEDS}
    return out

if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument("source",type=Path);cli.add_argument("record",type=Path);cli.add_argument("--write",action="store_true");a=cli.parse_args()
    actual=build(a.source)
    if a.write:a.record.write_text(json.dumps(actual,indent=2,sort_keys=True)+"\n")
    elif actual!=json.loads(a.record.read_text()):raise ValueError("fixture digest replay differed")
    else:print("Verified all fourteen fixture/seed hashes and both independent full-output integer/double product hashes.")
