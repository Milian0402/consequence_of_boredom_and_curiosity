"""Verify the portable certified-input benchmark without native hardware or a network connection."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
from zipfile import ZipFile

from numerical import assess, ensure, load
import native_evidence

RUN=45788542642
REV="c609245c8d7359b1e484c7d0896e3ad9a32a97a9"
RELEASE="e4b7ce19cdf49f9175c86d3e91ea8d3a756eae9b"
ARCHES=("x86_64","aarch64")

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(root):
    files=sorted(p for p in root.rglob("*") if p.is_file() and p.relative_to(root).as_posix()!="SHA256SUMS")
    return "".join(f"{digest(p)}  {p.relative_to(root).as_posix()}\n" for p in files)

def archive_receipt(root,archive=None):
    receipt=load(root/"provenance.json");members=load(root/"members.json");a=receipt["arch"]
    ensure(a==root.name and a in ARCHES and receipt["run"]==RUN and receipt["source_sha"]==receipt["benchmark_sha"]==REV and
           receipt["branch"]=="bench/certified-inputs" and receipt["job"]=="Certified inputs on "+a and receipt["attempt"]>0 and
           receipt["artifact"]==f"certified-inputs-{a}-{RUN}-{receipt['attempt']}" and receipt["zipped_crc_passed"] and receipt["artifact_id"]>0 and
           receipt["job_id"]>0 and receipt["status"] in ("success","failure"),"official receipt/run/commit/CPU mismatch")
    for n,e in members.items():
        p=root/"raw"/n
        ensure(Path(n).name==n and p.is_file() and digest(p)==e["sha256"],"public raw member changed "+n)
    if archive:
        ensure(digest(archive)==receipt["artifact_sha256"] and archive.stat().st_size==receipt["bytes"],"original zip digest/size")
        with ZipFile(archive) as z:
            names=[s.filename for s in z.infolist() if not s.is_dir()]
            ensure(z.testzip() is None and len(names)==len(set(names))==receipt["members"],"original zip CRC or duplicate entries")
            for n,e in members.items():
                ensure(z.read(e["member"])==(root/"raw"/n).read_bytes(),"changed original benchmark evidence "+n)
        native_evidence.verify_archive(root/"raw",archive)
    return receipt

def score_host(root,arch):
    host=root/arch;raw=host/"raw"
    native=native_evidence.verify(raw)
    if not (raw/"score.json").is_file():
        return dict(host=load(host/"provenance.json")["model"],state="incomplete",available=sorted(load(host/"members.json")),native=native)
    source=root/"source/exact"
    for f in ("panel.csv","protocol.md"):
        ensure((raw/f).read_bytes()==(source/f).read_bytes(),"frozen panel or protocol changed")
    ensure((raw/"benchmark-sha.txt").read_text().strip()==REV and (raw/"release-sha.txt").read_text().strip()==RELEASE,"wrong native source")
    official=load(raw/"score.json")
    sys.path.insert(0,str(source/"driver"))
    import score
    trial=score.compute(load(raw/"measurement.json"),[json.loads(l) for l in (raw/"observations.jsonl").read_text().splitlines()])
    ensure(trial==official,"detailed frozen-score replay failed")
    with tempfile.TemporaryDirectory() as tmp:
        stage=Path(tmp);score.write_results(stage,trial)
        ensure((stage/"comparisons.csv").read_bytes()==(raw/"comparisons.csv").read_bytes(),"frozen comparison table changed")
    answer=assess(host,arch,source,load(root/"input-digests.json"));answer["native"]=native;answer["state"]="scored"
    return answer

def verify(root, archives):
    ensure(snapshot(root)==(root/"SHA256SUMS").read_text(),"package checksum or membership mismatch")
    source=load(root/"source.json")
    ensure(source["revision"]==REV and source["release"]==RELEASE,"source identity")
    for n,h in source["git_blobs"].items():
        b=(root/n).read_bytes()
        ensure(hashlib.sha1(f"blob {len(b)}\0".encode()+b).hexdigest()==h,"source Git blob changed "+n)
    expected=None
    for arch in ARCHES:
        host=root/arch;archive_receipt(host,archives.get(arch))
        result=score_host(root,arch)
        ensure(result==load(host/"audit.json"),"independent qualification or timing replay differs")
        if result["state"]=="scored":
            if expected is None:expected=result["goldens"]
            else:ensure(expected==result["goldens"],"full signed/weight goldens differ between hosts")
    from render import render
    with tempfile.TemporaryDirectory() as tmp:
        path=Path(tmp)
        render(root,path/"README.md")
        for name in ("README.md","peer-comparisons.csv"):
            ensure((root/name).read_bytes()==(path/name).read_bytes(),"published table or Markdown differs from replay "+name)
    print("Verified both official host records, all present observations, source and corpus hashes, frozen and independent ranking replays.")

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive-x86_64",type=Path);p.add_argument("--archive-aarch64",type=Path)
    a=p.parse_args();verify(Path(__file__).resolve().parent,{"x86_64":a.archive_x86_64,"aarch64":a.archive_aarch64})
