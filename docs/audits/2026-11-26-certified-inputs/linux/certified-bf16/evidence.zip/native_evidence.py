"""Project native qualification artifacts and recheck them offline against original optional ZIP members."""
import hashlib
import json
import re
import zipfile
from pathlib import Path, PurePosixPath

BENCHMARK = 'c609245c8d7359b1e484c7d0896e3ad9a32a97a9'
RELEASE = 'e4b7ce19cdf49f9175c86d3e91ea8d3a756eae9b'
PANEL_SHA = 'e0334ce593ec84a5479cf8c13791d0b5cf7d91c29e532260968078a96e3104b6'
PROTOCOL_SHA = '3881153541a1e453e90a7f8fab20b336c3b0fb2de8e53a5411cbbc465c8350bb'
SHAPES = {'square4096':(4096,4096,4096), 'heldout':(1079,1553,1201),
          'optdigits':(1797,3823,64), 'optdigits-images':(1797,1934,1024)}
FAMILIES = {**{k:k for k in SHAPES},'early-reject':'heldout','late-reject':'heldout'}
DNNL_X86 = '9a6c34dd237ed50d5c6b26522ffa2f4f5135e4899a9fef03ea7ea20cba1e1a0a'
ACL_DSO = '321fd6d02efe5d0cd1fa126f581d2addb5b36bdf7ab3c288c7b4d9c55bb5e8f0'
ACL_SDK = '408cf4d5b3ea81031f915506f90977fba7549abc7dbff5929562b5767e215117'
ACL_NAME = 'a64_interleaved_bf16fp32_mmla_8x12'
ACL_SYMBOL = '_ZN8arm_gemm34a64_interleaved_bf16fp32_mmla_8x12EPKN11arm_compute8bfloat16ES3_Pfiii'
HEX = re.compile(r'[0-9a-f]{64}')


def check(ok, message):
    if not ok:
        raise ValueError('native evidence: '+message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()


def hashes(lines):
    out={}
    for line in lines:
        match=re.fullmatch(r'([0-9a-f]{64})\s+[ *]?(.+?)',line.strip())
        if match:
            name=PurePosixPath(match[2]).name
            check(name not in out,'duplicate product '+name)
            out[name]=match[1]
    return out



def public_line(line):
    # Only hosted source URLs survive intact. Absolute host paths retain their final file name.
    url_or_path=re.compile(r'https?://[^\s,<>]+|(?<![A-Za-z0-9_:/])/(?:[^\s=,:;<>]+)')
    def reduce(match):
        token=match[0]
        if token.startswith(('https://github.com/','https://codeload.github.com/','https://pypi.org/','https://files.pythonhosted.org/')):
            return token.split('?',1)[0]
        return PurePosixPath(token.split('?',1)[0]).name
    return url_or_path.sub(reduce,line)

def project(mode,data):
    if mode=='exact-bytes':return data
    if mode=='proof-diagnostics':
        def scrub(x):
            if isinstance(x,dict):return {k:scrub(v) for k,v in x.items()}
            if isinstance(x,list):return [scrub(v) for v in x]
            return public_line(x) if isinstance(x,str) else x
        return json_bytes(scrub(json.loads(data)))
    lines=data.decode().splitlines()
    if mode=='public-lines':return ('\n'.join(public_line(s) for s in lines)+'\n').encode()
    if mode=='product-sha256-by-basename':
        return json_bytes(hashes(lines))
    if mode=='elf-dependencies':
        mapped={}
        for line in lines:
            if '=>' not in line:continue
            key,rhs=line.strip().split('=>',1);path=rhs.strip().split(' ')[0]
            check(path.startswith('/'),'unresolved ELF dependency '+key)
            mapped[key.strip()]=PurePosixPath(path).name
        return json_bytes(mapped)
    if mode=='measurement-bindings':
        m=json.loads(data)
        return json_bytes({k:m[k] for k in ('methods','bindings','skips','cpu','panel_sha256','worker_sha256')})
    if mode=='provider-fingerprints':
        # Retain numerical hashes and version/ISA/thread evidence, elide ephemeral SDK/build paths.
        lines=[public_line(line) for line in lines if re.search(r'[a-f0-9]{64}|version|configured|threads?=|commit|serial|sha256|sequential|revision|https?://',line,re.I)]
        return ('\n'.join(lines)+'\n').encode()
    if mode=='build-test':
        return ('\n'.join(s.strip() for s in lines if 'tests passed' in s or 'tests failed' in s or 'Test #' in s)+'\n').encode()
    raise ValueError('unknown native evidence projection '+mode)


def inventory(raw):
    identity=['benchmark-sha.txt','release-sha.txt','cpu.txt','lscpu.txt','panel.csv','protocol.md','admissions.json',
              'build/bf16-build.txt','build/acl-identity.json','build/popcount-instructions.txt','onednn/github.json',
              'onednn/runtime.tgz.sha256','restoration-status.txt']
    pairs={name:('exact-bytes',name) for name in identity}
    for name in SHAPES:
        for kind in ('bf16','int8'):
            filename=f'proof/{name}-{kind}.json';pairs[filename]=('exact-bytes',filename)
    pairs['build/products.sha256']=('product-sha256-by-basename','build/products.json')
    for path in ('build/raw-bf16.ldd','build/release-mkl-aligned-two.ldd'):
        pairs[path]=('elf-dependencies',path+'.json')
    for filename in ('qualified-oneshot.log','qualified-cached-plan.log','build-fingerprint.txt'):
        name='onednn/'+filename;pairs[name]=('public-lines',name)
    pairs['measurement.json']=('measurement-bindings','timed-bindings.json')
    for p in sorted((raw/'vendor-builds').glob('*.txt')):
        name=p.relative_to(raw).as_posix();pairs[name]=('provider-fingerprints',name)
    for p in sorted((raw/'build').glob('*.test')):
        name=p.relative_to(raw).as_posix();pairs[name]=('build-test',name)
    return {name:spec for name,spec in pairs.items() if (raw/name).is_file()}


def gather(raw,destination,archive_files=None):
    raw=Path(raw);dest=Path(destination)/'native-proof';dest.mkdir(parents=True,exist_ok=True)
    if isinstance(archive_files,(str,Path)):archive_files=json.loads(Path(archive_files).read_bytes())
    members={}
    for name,(mode,proj) in inventory(raw).items():
        original=(raw/name).read_bytes();fingerprint=sha(original);member=name
        if name.startswith('proof/') and re.search(rb'/(work|Users|tmp|private|home|opt|usr|var)/',original):
            mode='proof-diagnostics'
        if archive_files is not None:
            choices=[k for k,v in archive_files.items() if v==fingerprint and (k==name or k.endswith('/'+name))]
            check(len(choices)==1,'missing/ambiguous authenticated member '+name);member=choices[0]
        mapped=project(mode,original)
        (dest/proj).parent.mkdir(parents=True,exist_ok=True);(dest/proj).write_bytes(mapped)
        members[name]={'member':member,'source_sha256':fingerprint,'path':proj,'projection_sha256':sha(mapped),'transform':mode}
    (dest/'membership.json').write_bytes(json_bytes(members))
    return verify(destination)


def verify_archive(destination,original_zip):
    dest=Path(destination)/'native-proof';records=json.loads((dest/'membership.json').read_bytes())
    with zipfile.ZipFile(original_zip) as archive:
        for key,rec in records.items():
            match=[i for i in archive.infolist() if i.filename==rec['member']]
            check(len(match)==1,'missing/duplicate member '+key)
            source=archive.read(match[0]);check(sha(source)==rec['source_sha256'],'original changed '+key)
            check(project(rec['transform'],source)==(dest/rec['path']).read_bytes(),'projection replay '+key)
    return verify(destination)


def observed_data(lines, tag):
    return [r.split(',')[1:] for r in lines if r.startswith(tag+',')]


def full_executions(lines,shape,cpu,implementation,route):
    m,n,k=shape
    check(observed_data(lines,'BF16_PLAN')==[['0',implementation,route,'1']], 'BF16 descriptor record')
    check(observed_data(lines,'BF16_LIFE')==[['1','2','1']],'BF16 independent one-plan/two-execution lifetime')
    results=observed_data(lines,'BF16_EXEC');check(len(results)==2,'BF16 operation count')
    for i,row in enumerate(results):
        index,ret,checked,guards,wrong,changed,worst,unchanged,threads,actual_cpu,calls=row
        check([int(x) for x in (index,ret,checked,guards,wrong,changed,unchanged,threads,actual_cpu,calls)]==
              [i,0,m*n,24+3*i,0,0,1,1,cpu,i+1] and float(worst)==0,'BF16 full exact result/guard/CPU')


def valid_verbose(row,impl,shape,datatypes):
    m,n,k=shape
    return (',exec,cpu,matmul,'+impl+',' in row and f',{m}x{k}:{k}x{n},' in row and
            all(re.search(r'\b'+field+r'[:_]'+kind+r'\b',row) for field,kind in zip(('src','wei','dst'),datatypes)))


def bf16(proof,shape,arch,cpu,build_sha,build):
    m,n,k=shape;enabled=proof['eligible'];check(type(enabled) is bool,'BF16 eligibility type')
    if 'shape_and_strides' in proof:
        check(proof['shape_and_strides']==[m,n,k,k,n,n],'BF16 geometry/row strides differ')
    if 'architecture' in proof:
        check(proof['architecture']==arch and proof['affinity_cpu']==cpu and proof['emulated'] is False,'BF16 host/CPU/emulation')
    result={'eligible':enabled,'reason':proof.get('reason',''),'implementation':proof.get('implementation',''),
            'route':proof.get('route',''),'status':proof.get('status'),'checked_outputs':proof.get('checked_outputs',0)}
    if not enabled:
        check(bool(result['reason']) and result['reason']!='verified-native-instruction-and-output','BF16 exclusion reason')
        if arch=='x86_64' and proof.get('status')==3:
            check(bool(observed_data(proof['raw_worker_records'],'BF16_ERROR')) and observed_data(proof['raw_worker_records'],'BF16_LIFE')==[['0','0','0']], 'unimplemented descriptor accounting')
        return result
    check(result['reason']=='verified-native-instruction-and-output' and proof['shape_and_strides']==[m,n,k,k,n,n] and
          proof['architecture']==arch and proof['affinity_cpu']==cpu and proof['emulated'] is False,'native execution receipt identity')
    check(proof['build_receipt_sha256']==build_sha,'proof differs from archived build receipt')
    name=result['implementation'];route=result['route'];features=set(proof['host_relevant_features'])
    if arch=='x86_64':
        flags,op={'x86-amx-bf16':({'amx_tile','amx_bf16'},'tdpbf16ps'),'x86-avx512-bf16':({'avx512_bf16'},'vdpbf16ps')}[route]
        check(bool(name) and flags<=features and proof['returncode']==proof['status']==0 and proof['checked_outputs']==2*m*n,'x86 BF16 execution')
        lines=build.decode().splitlines();fingerprints=hashes(lines)
        check(fingerprints['bf16-probe']==proof['probe_sha256'] and fingerprints['libbf16_backend.so']==proof['bridge_sha256'] and
              proof['mapped_onednn_sha256']==DNNL_X86 and 'libdnnl_sha256='+DNNL_X86 in lines,'pinned x86 oneDNN and bridge')
        check(any('runtime:sequential,nthr:1' in row for row in proof['verbose_runtime_records']),'oneDNN single-thread runtime')
        events=proof['verbose_exec_records'];check(len(events)==2 and all(valid_verbose(s,name,shape,('bf16','bf16','f32')) for s in events),'x86 verbose dtype/shape')
        full_executions(proof['raw_worker_records'],shape,cpu,name,route)
        instructions=proof['jit_bf16_instructions'];check(len(instructions)<=proof['jit_dump_count'],'JIT dump count')
        found=[x for x in instructions if re.match(r'dnnl_dump_cpu_jit_(brgemm|bf16_matmul)',x['kernel_file']) and
               x['instruction_example'].split()[0].lower()==op and x['instruction_sites']>0 and x['bytes']>0 and HEX.fullmatch(x['sha256'])]
        check(bool(found),'missing specific BF16 native instruction')
        result.update(opcodes=[op],static_instruction_sites=sum(x['instruction_sites'] for x in found),guard_cells=51,kernel_hashes=[x['sha256'] for x in found])
    else:
        ident=json.loads(build);fingerprints=ident['sha256'];check(proof['source_identity']==ident,'ACL direct build linkage')
        check((name,route)==(ACL_NAME,'arm-acl-neon-bfmmla') and {'asimd','bf16'}<=features and
              (ident['acl_dso_sha256'],ident['sdk_sha256'],ident['kernel_symbol'])==(ACL_DSO,ACL_SDK,ACL_SYMBOL),'ACL native ISA/digest')
        check(ident['bfmmla_static_count']==proof['opcode_sites']>0 and re.search(r'\bbfmmla\s+v\d+\.4s',proof['instruction_example']) and
              fingerprints['acl-kernel.txt']==proof['kernel_disassembly_sha256'],'pinned ACL arithmetic kernel disassembly')
        A=(m+7)//8;B=(n+11)//12;K=(k+3)//4*4;calls=((A+7)//8)*((B+7)//8)
        expected={key:str(v) for key,v in dict(name=ACL_NAME,calls=calls,abytes=A*8*K*2,bbytes=B*12*K*2,
                     cbytes=min(A,8)*min(B,8)*8*12*4,allocations=2,m=m,n=n,k=k,ablocks=A,bblocks=B,kp=K,planbytes=96).items()}
        for mode,file in [('ordinary','acl-probe'),('trace','acl-probe-trace')]:
            r=proof[mode];check(r['probe_sha256']==fingerprints[file] and r['checked_outputs']==2*m*n and r['guard_cells']==51,'ACL checked outputs/canaries/worker')
            full_executions(r['raw_worker_records'],shape,cpu,name,route)
            raw=observed_data(r['raw_worker_records'],'ACL_BF16_KERNEL')
            actual=[dict(item.split('=',1) for item in row) for row in raw]
            check(actual==([expected,expected] if mode=='trace' else []) and r['observed_trace']==(expected if mode=='trace' else None),'ACL actual callbacks/counts/bytes')
        check(proof['checked_outputs']==4*m*n and proof['guard_cells']==102,'ACL total output coverage')
        result.update(opcodes=['bfmmla'],static_instruction_sites=proof['opcode_sites'],kernel_calls_per_execution=calls,guard_cells=102,kernel_hashes=[ACL_DSO])
    return result


def int8(proof,shape,cpu,arch):
    m,n,k=shape;check(proof['shape']==[m,n,k] and type(proof['eligible']) is bool,'INT8 shape/eligibility')
    name=proof['implementation'];ops={};allowed=({'tdpbssd','tdpbusd','vpdpbssd','vpdpbusd','vpmaddubsw'} if arch=='x86_64'
                                                else {'sdot','udot','smmla','ummla','usmmla','sudot','usdot','smull'})
    for item in proof['jit_instruction_evidence']:
        check(HEX.fullmatch(item['sha256']) and re.search(r'gemm|matmul',item['kernel']) and set(item['operations'])<=allowed,'INT8 instruction witness')
        ops[item['kernel']]=sorted(item['operations'])
    check(bool(ops)==proof['native_integer_opcodes_observed'],'INT8 opcode disclosure')
    if proof['eligible']:
        check(proof['returncode']==0 and bool(name) and 'ref' not in name.lower(),'executed INT8 implementation')
        check(proof['probe']==[f'INT8_PROOF,{name},1,{m*n},1,{cpu}'],'INT8 full integer output and CPU')
        check(any('runtime:sequential,nthr:1' in s for s in proof['runtime']) and
              any(valid_verbose(s,name,shape,('s8','s8','s32')) for s in proof['events']),'sequential s8/s8/s32 executed primitive')
    return dict(eligible=proof['eligible'],implementation=name,reason=proof['reason'],returncode=proof['returncode'],
                checked_outputs=m*n if proof['eligible'] else 0,opcodes=sorted({x for line in ops.values() for x in line}),
                native_opcodes_observed=bool(ops),jit_function_count=len(ops))


def verify(destination):
    dest=Path(destination)/'native-proof';members=json.loads((dest/'membership.json').read_bytes());missing=[]
    paths=set()
    for name,r in members.items():
        paths.add(r['path']);rel=PurePosixPath(r['path'])
        check(not rel.is_absolute() and '..' not in rel.parts and HEX.fullmatch(r['source_sha256']) and
              sha((dest/rel).read_bytes())==r['projection_sha256'],'invalid native proof member '+name)
        if r['transform']=='exact-bytes':check(r['source_sha256']==r['projection_sha256'],'verbatim proof hash '+name)
    def optional(name):
        if name in paths:return (dest/name).read_bytes()
        missing.append(name);return None
    def parsed(name):
        data=optional(name);return json.loads(data) if data is not None else None
    host=optional('lscpu.txt');text=host.decode() if host else ''
    cpuinfo={k.strip():v.strip() for k,v in (r.split(':',1) for r in text.splitlines() if ':' in r)}
    arch=cpuinfo.get('Architecture')
    if host:check(arch in ('aarch64','x86_64'),'native platform name')
    cpu_text=optional('cpu.txt');cpu=int(cpu_text) if cpu_text is not None else None
    for name,expected in [('benchmark-sha.txt',BENCHMARK),('release-sha.txt',RELEASE)]:
        data=optional(name)
        if data is not None:check(data.decode().strip()==expected,'frozen source '+name)
    for name,expected in [('panel.csv',PANEL_SHA),('protocol.md',PROTOCOL_SHA)]:
        data=optional(name)
        if data is not None:check(sha(data)==expected,'registered '+name)
    coverage={};admissions=parsed('admissions.json') or {};timed=parsed('timed-bindings.json') or {}
    if admissions:check(set(admissions)==set(FAMILIES),'admissions geometries')
    methods=timed.get('methods',{})
    products=parsed('build/products.json') or {}
    runtime=parsed('build/raw-bf16.ldd.json') or {}
    build=None
    if arch:
        identity='build/bf16-build.txt' if arch=='x86_64' else 'build/acl-identity.json'
        build=optional(identity)
        lab='libbf16_backend.so' if arch=='x86_64' else 'libacl_bf16_backend.so'
        if runtime:check(runtime.get(lab)==lab and ('libdnnl.so.3' if arch=='x86_64' else 'libarm_compute.so') in runtime,'raw-bf16 linked provider')
    if arch=='x86_64' and build:
        actual=hashes(build.decode().splitlines())
        frozen={'backend.cpp':'c42d143ac7a6151658d56dda59e67991ed6fb886b9ac80e5ff55888faa1378e8',
                'backend.h':'9a2dc0e4e10547f13d1dd638bf11a4db4e3dfc82b8e35835660cb5966984621a',
                'build.sh':'deefdcd806043ffff8edd194c2d8a22baddd450660103ea2c91706b67c60347f',
                'probe.cpp':'9c9776c21ca366f336ad2d6b8fcc8db0836c0793204039d2990f6789ef63f328'}
        check(all(actual.get(n)==digest for n,digest in frozen.items()),'BF16 sources disagree with immutable source commit')
    if arch=='x86_64':
        linked=parsed('build/release-mkl-aligned-two.ldd.json') or {}
        if linked:check({'libmkl_intel_lp64.so.3','libmkl_sequential.so.3','libmkl_core.so.3'}<=set(linked),'MKL LP64/SEQ release dependency')
    if methods:
        check(timed['panel_sha256']==PANEL_SHA and (cpu is None or timed['cpu']==cpu),'timed host/panel')
        if products:
            check(timed['worker_sha256']==products.get('exact.worker'),'ordinary worker SHA')
            expected={'cob-standalone','onednn-int8','raw-bf16','exact-dispatch','fp32-policy','bitset-popcount'}
            if arch=='x86_64':expected.add('release-mkl-aligned-two')
            for n in expected:check(HEX.fullmatch(products.get(n+'.so','')) and products[n+'.so']==methods[n]['plugin_sha256'],'method binary '+n)
    if len(products)>0:check(all(HEX.fullmatch(v) for v in products.values()),'product hashes')
    for family,shape in SHAPES.items():
        coverage[family]={}
        for kind in ('bf16','int8'):
            name=f'proof/{family}-{kind}.json';p=parsed(name)
            if p is None:continue
            if arch is None or cpu is None:
                coverage[family][kind]={'eligible':False,'reason':'native host or CPU receipt missing','declared_eligible':p['eligible']}
            elif kind=='int8':coverage[family][kind]=int8(p,shape,cpu,arch)
            elif build is None and p['eligible']:
                coverage[family][kind]={'eligible':False,'reason':'build identity missing','declared_eligible':True}
            else:coverage[family][kind]=bf16(p,shape,arch,cpu,sha(build or b''),build)
    policies={}
    if timed and set(timed['bindings'])!=set(FAMILIES):missing.append('paused study bindings for '+','.join(sorted(set(FAMILIES)-set(timed['bindings']))))
    for family,source in FAMILIES.items():
        p=admissions.get(family);timing=timed.get('bindings',{}).get(family)
        if arch is None or p is None:continue
        large=(min(SHAPES[source])>=4096 and max(SHAPES[source])<=2*min(SHAPES[source]))
        target=(('release-mkl-aligned-two' if large else 'mkl-jit') if arch=='x86_64' else ('fastmmw-1536' if large else 'armpl'))
        check(p['fallback_method']==target and p['proof']==f'proof/{source}-bf16.json' and p['int8_proof']==f'proof/{source}-int8.json','frozen fallback and shared probe semantics '+family)
        for kind,ok,impl in [('bf16','eligible','implementation'),('int8','int8_eligible','int8_implementation')]:
            report=coverage[source].get(kind)
            if report is not None and 'declared_eligible' not in report:
                check(report['eligible']==p[ok] and report['implementation']==p[impl],'native probe/admissions '+family+' '+kind)
                if kind=='bf16':check(report['reason']==p['reason'],'recorded BF16 exclusion reason')
        policy={'backend':target,'large':large}
        if timing:
            check(timing['native']==p['eligible'] and timing['implementation']==p['implementation'] and timing['reason']==p['reason'] and
                  timing['int8_eligible']==p['int8_eligible'] and timing['int8_implementation']==p['int8_implementation'] and timing['fallback_method']==target,'timed native and fallback declarations '+family)
            check(timing['fast_sha256']==methods['raw-bf16']['plugin_sha256'] and timing['fallback_sha256']==methods['fp32-policy']['plugin_sha256'] and
                  HEX.fullmatch(methods[target]['plugin_sha256']),'timed endpoints must be the named DSO products')
            failed=timed['skips'][family]
            check(('raw-bf16' not in failed)==p['eligible'],'raw BF16 conditional presence')
            check(('onednn-int8' not in failed)==(family not in ('early-reject','late-reject') and p['int8_eligible']),'INT8 conditional presence')
            policy.update(backing_sha256=methods[target]['plugin_sha256'],selector_sha256=timing['fallback_sha256'],bf16_sha256=timing['fast_sha256'])
        policies[family]=policy
    restored={}
    if arch:
        asset,zip_sha,tar_sha,dll_sha={
            'x86_64':(15049984729,'df9673efd4ab4cf3b382e9392a0c17bdb324a018ef13aaba14df242ff8a0ae8d','1c799951bbb5a057a6e374daf7093c19033fd8c64bc7300fe0a962232c012634',DNNL_X86),
            'aarch64':(15050168540,'320291dc07053789ccc0ef0c91a5dd2df6d5558021aac83ebb8df2aaccf7f227','bff8aa7a2e6f9e9720de6b5f746fa99e3b1b70b357cf712771d638c3e9edd2e4','e8ec604abd0edb3c77656329bb76f64a5809d499ae4001c8182a9cb769e3287d')}[arch]
        old=parsed('onednn/github.json');tar=optional('onednn/runtime.tgz.sha256');finger=optional('onednn/build-fingerprint.txt')
        if old:
            check((old['id'],old['digest'],old['name'],old['workflow_run']['id'],old['workflow_run']['head_sha'])==
                (asset,'sha256:'+zip_sha,f'onednn-{arch}-45672997916-1',45672997916,'29f5817ed45a728bc012f332fa378dc95c6e7ef5'),'restored oneDNN artifact and upstream run')
            restored.update(artifact_id=asset,archive_sha256=zip_sha)
        if tar:check(hashes(tar.decode().splitlines()).get('runtime.tgz')==tar_sha,'oneDNN extracted SDK checksum')
        if finger:
            lines=finger.decode().splitlines();prints=hashes(lines)
            check(prints.get('libdnnl.so')==dll_sha and 'source_tag=v3.14.2' in lines and
                  'source_commit=4db284662a37cf46401655b5ee99391d9de52c00' in lines,'pinned provider runtime/oneDNN sources')
            if methods:
                for variant in ('oneshot','cached-plan'):
                    check(prints['onednn-f32-'+variant+'.so']==methods['onednn-'+variant]['plugin_sha256'],'actual FP32 runtime adapter digest')
            restored.update(runtime_sha256=dll_sha,upstream_revision='4db284662a37cf46401655b5ee99391d9de52c00')
        for variant,num in [('oneshot',11),('cached-plan',6)]:
            test=optional('onednn/qualified-'+variant+'.log')
            if test:check(f'PASS full_fp64_outputs=73096 created_plans={num}' in test.decode().splitlines(),'strict oneDNN precision/plan-count preflight')
    ops=optional('build/popcount-instructions.txt') or b''
    popcount=[opcode for line in ops.decode().splitlines()
              if re.match(r'\s*[0-9a-f]+:',line)
              for opcode in re.findall(r'\b(v?popcnt[a-z]*|cnt(?=\s+v[0-9]+))\b',line,re.I)]
    test_names=['cob-standalone']+(['release-mkl-aligned-two'] if arch=='x86_64' else [])
    passed={}
    for name in test_names:
        result=optional('build/'+name+'.test')
        if result is not None:
            passed[name]=bool(re.search(rb'100% tests passed, 0 tests failed out of [1-9]',result))
            check(passed[name],'ordinary release build failed native CTest: '+name)
    return dict(state='partial' if missing else 'verified',arch=arch,cpu=cpu,
                restored_onednn=restored,
                binary_specialist={'assembly_opcodes':sorted(set(popcount)),'recorded_static_sites':len(popcount)},build_tests=passed,
                hardware={'model':cpuinfo.get('Model name'),'vendor':cpuinfo.get('Vendor ID'),'relevant_cpu_flags':sorted(set(cpuinfo.get('Flags','').split()) &
                    {'avx512_bf16','amx_tile','amx_bf16','amx_int8','avx512_vnni','bf16','asimd','i8mm','sve','svebf16','asimddp'})},
                geometries=coverage,admissions=admissions,methods=methods,fallbacks=policies,missing=sorted(missing),
                limitations=['INT8 admission requires a successful nonreference integer primitive; instruction-specific attribution additionally requires retained opcode evidence.',
                'FP32 backing selection is bound by frozen source, shape, configured library and its digest. The worker has no internal backing branch or provider leaf counter.',
                'Generated or static assembly identifies instructions present in the bound kernel. It supplies no retired-instruction count.'])
