"""Render authenticated exact-input Linux SGEMM score files and all measured peer comparisons."""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
from statistics import median

ARCHES = ("x86_64", "aarch64")
STAGES = ("FIRST", "WARM")
CANDIDATE = "exact-dispatch"
REPO = "https://github.com/Milian0402/consequence_of_boredom_and_curiosity"
NAMES = {"square4096": "Signed cube", "heldout": "Signed rectangle", "early-reject": "First A + ½",
         "late-reject": "Last B + ½", "optdigits": "UCI feature counts", "optdigits-images": "UCI binary pixels"}


def read(path):
    return json.loads(path.read_text())


def display(name):
    return f"`{name}`" if name else "—"


def label(family):
    return NAMES.get(family, family)


def ms(value):
    return f"{value:,.3f}" if value is not None else "—"


def stage_median(case, method, stage):
    return case["evidence"].get(method, {}).get("medians_ms", {}).get(stage)


def ratio(row):
    if not row:
        return "—"
    return f"{row['paired_median']:.3f}× ({row['wins']}/6)"


def against(case, stage, group=None, peer=None):
    stage_data = case["candidate_comparisons"].get(stage, {})
    if group:
        return stage_data.get("strongest", {}).get(group)
    return stage_data.get("peers", {}).get(peer)


def leader_cell(case, stage, group):
    peer = case["leaders"][stage].get(group)
    if not peer:
        return "—"
    row = against(case, stage, group=group)
    return f"{display(peer)} {ratio(row)}" if row else display(peer)


def fixed_cell(case, stage, peer):
    return ratio(against(case, stage, peer=peer))


def load_host(root, arch):
    folder = root / arch
    receipt = read(folder / "provenance.json")
    if receipt["arch"] != arch:
        raise ValueError(f"{arch} receipt mismatch")
    audit_file = folder / "audit.json"
    audit = read(audit_file) if audit_file.is_file() else {}
    native = audit.get("native", {})
    raw = folder / "raw"
    if not (raw / "score.json").is_file():
        return dict(arch=arch, receipt=receipt, native=native, score=None, available=audit.get("available", []))
    score = read(raw / "score.json")
    measurement = read(raw / "measurement.json")
    models = [line.partition(":")[2].strip() for line in (raw / "lscpu.txt").read_text().splitlines()
              if line.partition(":")[0].strip() == "Model name"]
    admissions = read(raw / "admissions.json")
    return dict(arch=arch, receipt=receipt, native=native, score=score, measurement=measurement, admissions=admissions,
                model=receipt.get("model") or next(iter(models), arch))


def measured(host):
    return host["score"] and host["score"].get("cases")


def summary(host):
    if not measured(host):
        r = host["receipt"]
        return f"- **{r.get('model') or host['arch']}** has no completed score. [Hosted job]({r['job_url']})"
    cases = host["score"]["cases"]
    native = [case for case in cases.values() if case["expected_native"]]
    def counted(stage, group):
        rows = [against(c, stage, group=group) for c in native]
        return f"{sum(bool(r and r['passes']) for r in rows)}/{len(native)}"
    model = host["model"]
    parts = [f"**{model}.**"]
    if native:
        parts.append(f"Of {len(native)} admitted integer fixtures, the candidate cleared the paired rule against "
                     f"the fastest qualified one-shot FP32 method on {counted('FIRST','fp32_oneshot')} first calls "
                     f"and {counted('WARM','fp32_oneshot')} warm calls. Against the quickest eligible peer of any kind, "
                     f"the warm count was {counted('WARM','all_qualified')}.")
        corpus = []
        for key in ("optdigits", "optdigits-images"):
            c = cases.get(key)
            row = against(c, "WARM", group="fp32_oneshot") if c and c["expected_native"] else None
            if row:
                corpus.append(f"{row['paired_median']:.3f}× versus {display(row['peer'])} on the {c['dimensions'][2]}-input representation")
        if corpus:
            parts.append("Warm ratios on UCI digits were " + " and ".join(corpus) + ".")
    else:
        parts.append("The BF16 route qualified on none of the registered integer fixtures. Candidate timings measure the ordinary FP32 fallback.")
    return "- " + " ".join(parts)


def exclusion_notes(cases):
    exclusions = defaultdict(list)
    for family, case in cases.items():
        for n, reason in case["skips"].items():
            exclusions[n, reason].append(label(family))
        for n, e in case["evidence"].items():
            if n not in case["structural"]:
                reason = "; ".join(e["structural_issues"]) or "incomplete worker records"
            elif n not in case["qualified_numerical"]:
                reason = f"failed numerical gate in {e['failed_numerical_calls']}/12 calls"
            else:
                continue
            exclusions[n, reason].append(label(family))
    if not exclusions:
        return ["All registered methods qualified numerically on every fixture."]
    return [f"- {display(n)} — {reason.replace('|', '/')} ({', '.join(families)})."
            for (n, reason), families in exclusions.items()]


def signed_int8_cube(cases):
    c = cases.get("square4096")
    method = "onednn-int8"
    if not c or method not in c["qualified_exact"]:
        return []
    peer = c["leaders"]["WARM"]["fp32_oneshot"]
    if not peer:
        return []
    ordinary = c["evidence"][peer]["times_s"]["WARM"]
    integer = c["evidence"][method]["times_s"]["WARM"]
    pairs = [b/a for b, a in zip(ordinary, integer, strict=True)]
    wins = sum(x > 1 for x in pairs)
    observed = ", ".join(f"{v:.3f}" for v in pairs)
    return ["", f"On the signed 4096³ cube, exact {display(method)} took {ms(median(integer)*1000)} ms warm "
            f"against {ms(median(ordinary)*1000)} ms for {display(peer)}, the fastest qualified one-shot FP32 method. "
            f"Its directly paired speedup was **{median(pairs):.3f}× ({wins}/6)**. "
            f"The six FP32/INT8 time ratios were {observed}. Each INT8 call validated and converted the incoming FP32 "
            "values to signed bytes, created its oneDNN primitive, multiplied and copied the signed 32-bit result back "
            "to FP32. The specialist aborts on inputs outside its certified domain."]


def write_host(host):
    arch, receipt = host["arch"], host["receipt"]
    if not measured(host):
        failed = [s["name"] for s in receipt.get("steps", []) if s.get("conclusion") == "failure"]
        detail = f"The hosted job failed at {', '.join(failed)}. " if failed else ""
        stages = [n for n in ("admissions.json", "measurement.json", "observations.jsonl") if n in host["available"]]
        if stages:
            detail += "The incomplete archive contains " + ", ".join(display(n) for n in stages) + ". "
        return [f"## {receipt.get('model') or arch}", "",
                detail + f"No complete scored panel is available from job {receipt['job_id']}. "
                f"[Hosted job]({receipt['job_url']}) · [Receipt]({arch}/provenance.json) · "
                f"[Available evidence]({arch}/audit.json)", ""]
    score, measure = host["score"], host["measurement"]
    cases = score["cases"]
    body = [f"## {host['model']}", "",
            f"The original job recorded {score['observations']:,} process runs on CPU {measure['cpu']}. "
            f"[Hosted job]({receipt['job_url']}) · [Artifact receipt]({arch}/provenance.json) · "
            f"[Timing records]({arch}/raw/observations.jsonl) · [Admission and provider evidence]({arch}/audit.json)", ""]
    observed = host["native"].get("geometries", {})
    if observed:
        body.extend(["BF16 qualification required exact full-output executions and a matching instruction witness. "
                     "The signed oneDNN INT8 qualification used s8×s8→s32 execution. Instruction names below come from the "
                     "linked or generated arithmetic kernel. A generic descriptor alone cannot identify its instruction set.", "",
                     "| Independently probed geometry | Executed BF16 route and instruction | Signed INT8 primitive and instruction evidence |",
                     "|---|---|---|"])
        for f, entries in observed.items():
            desc = []
            for kind in ("bf16", "int8"):
                probe = entries.get(kind, {})
                if not probe.get("eligible"):
                    desc.append("Unavailable · " + probe.get("reason", "receipt missing"))
                else:
                    instruction = ", ".join(display(x) for x in probe.get("opcodes", []))
                    desc.append(f"{display(probe['implementation'])} · " + (instruction or "no retained opcode witness"))
            body.append(f"| {label(f)} | {desc[0]} | {desc[1]} |")
        body.append("")
    else:
        hardware = defaultdict(list)
        for f in cases:
            adm = host["admissions"][f]
            status = display(adm["implementation"]) if adm["eligible"] else f"unavailable ({adm['reason']})"
            hardware[status].append(label(f))
        for status, families in hardware.items():
            body.append(f"- BF16 backend {status} on {', '.join(families)}.")
    providers = defaultdict(list)
    for f, c in cases.items():
        providers[c["binding"]["fallback_method"]].append(label(f))
    for method, families in providers.items():
        body.append(f"- Ordinary backing provider {display(method)} on {', '.join(families)}.")
    body.extend(["", "### Complete-call timings", "",
                 "The FP32 opponent has the lowest raw median among numerically qualified one-shot FP32 methods. "
                 "The last column gives the lowest raw median across the whole qualified field, including this candidate, "
                 "the unchecked BF16 control, exact integer specialists and retained plans when eligible.", "",
                 "| Fixture and call | Candidate ms | One-shot FP32 leader, ms | Paired speedup (wins) | Full-field raw leader, ms |",
                 "|---|---:|---|---:|---|"])
    for f, c in cases.items():
        dim = "×".join(map(str, c["dimensions"]))
        for stage in STAGES:
            peer = c["leaders"][stage]["fp32_oneshot"]
            best = c["leaders"][stage]["all_qualified"]
            body.append(f"| {label(f)} {dim} · {stage.lower()} | {ms(stage_median(c, CANDIDATE, stage))} | "
                        f"{display(peer)} {ms(stage_median(c, peer, stage))} | {ratio(against(c,stage,group='fp32_oneshot'))} | "
                        f"{display(best)} {ms(stage_median(c, best, stage))} |")
    body.extend(signed_int8_cube(cases))
    body.extend(["", "### Exact, independent and specialist comparisons", "",
                 "Each entry gives the named raw-median leader of its field and the candidate’s paired speedup against it. "
                 "Exact FP32 requires every output to equal its reference. The independent fields exclude the candidate, "
                 "its backing wrapper and released COB methods. The inclusive fields admit the retained oneDNN plan.", "",
                 "| Fixture and call | Exact FP32, any | Ordinary FP32, any | Independent FP32, one-shot | Independent FP32, any | Exact integer or binary |",
                 "|---|---|---|---|---|---|"])
    groups = ("fp32_exact", "fp32_any", "independent_fp32_oneshot", "independent_fp32_any", "integer_specialists")
    for f, c in cases.items():
        for stage in STAGES:
            cells = [f"{label(f)} · {stage.lower()}"] + [leader_cell(c, stage, g) for g in groups]
            body.append("| " + " | ".join(cells) + " |")
    body.extend(["", "### Backing provider, standalone COB and unchecked arithmetic", "",
                 "Ratios compare the candidate with a separately timed call on the same input. The unchecked BF16 control "
                 "omits the integer certificate. The signed INT8 provider and binary AND/popcount provider accept ordinary FP32 buffers "
                 "and include conversion or packing. A dash means the comparison did not qualify or was outside the registered domain.", "",
                 "| Fixture and call | Backing FP32 | Standalone COB | Raw BF16 | oneDNN INT8 | Binary AND/popcount |",
                 "|---|---:|---:|---:|---:|---:|"])
    peers = ("fp32-policy", "cob-standalone", "raw-bf16", "onednn-int8", "bitset-popcount")
    for f, c in cases.items():
        for stage in STAGES:
            cells = [f"{label(f)} · {stage.lower()}"] + [fixed_cell(c, stage, n) for n in peers]
            body.append("| " + " | ".join(cells) + " |")
    body.extend(["", "### Output and fallback checks", "",
                 "| Fixture | Timed route | Inexact outputs / checked | Largest absolute error | Ordinary FP32 methods exact / qualified |",
                 "|---|---|---:|---:|---:|"])
    for f, c in cases.items():
        e = c["evidence"].get(CANDIDATE)
        if not e or CANDIDATE not in c["structural"]:
            body.append(f"| {label(f)} | incomplete | — | — | — |")
            continue
        if c["expected_native"]:
            route = "one certified BF16 product"
        else:
            route = "FP32, hardware unavailable" if not c["binding"]["native"] else "FP32, fractional value"
        fp32 = set(measure["methods"]) - {CANDIDATE, "raw-bf16", "onednn-int8", "bitset-popcount"}
        count = len(fp32.intersection(c["qualified_exact"]))
        num = len(fp32.intersection(c["qualified_numerical"]))
        body.append(f"| {label(f)} | {route} | {e['inexact_values']:,} / {e['checked_values']:,} | {e['max_abs']:.6g} | {count}/{num} |")
    rejected = [c for c in cases.values() if c["spec"] in ("early","late") and CANDIDATE in c["structural"]]
    if rejected:
        scan = []
        for c in rejected:
            m, n, k = c["dimensions"]
            count = (min(64, k) if c["spec"] == "early" else (m+n)*k) if c["binding"]["native"] else 0
            scan.append(f"{count:,} on {'first A' if c['spec']=='early' else 'last B'}")
        body.extend(["", "The route records show " + " and ".join(scan) + " input values inspected. "
                     "The first and warmed results matched the selected FP32 backing call bit-for-bit in every qualified pair."])
    body.extend(["", "### Exclusions", "", *exclusion_notes(cases), "",
                 f"[All scored methods and raw medians]({arch}/raw/score.json) · "
                 f"[Six pairs for every registered comparison group]({arch}/raw/comparisons.csv) · "
                 f"[Per-geometry admissions]({arch}/raw/admissions.json)", ""])
    return body


def save_peer_csv(path, hosts):
    metadata = ["arch","model","family","spec","m","n","k","native_candidate","stage","peer","peer_role","peer_exact"]
    metrics = ["candidate_ms","peer_ms","raw_median_ratio","paired_median","wins","ties","passes","seed1_median","seed2_median"]
    with path.open("w", newline="") as out:
        writer = csv.writer(out, lineterminator="\n")
        writer.writerow(metadata + metrics + [f"pair_{i}" for i in range(1,7)])
        for h in hosts:
            if not measured(h):
                continue
            for f, c in h["score"]["cases"].items():
                for stage in STAGES:
                    for n, r in c["candidate_comparisons"].get(stage, {}).get("peers", {}).items():
                        writer.writerow([h["arch"], h["model"], f, c["spec"], *c["dimensions"], int(c["expected_native"]),
                                         stage, n, h["measurement"]["methods"][n]["role"], int(n in c["qualified_exact"]),
                                         stage_median(c,CANDIDATE,stage), stage_median(c,n,stage), r["raw_median_ratio"],
                                         r["paired_median"], r["wins"], r["ties"], int(r["passes"]),
                                         *r["seed_medians"], *r["paired_ratios"]])


def render(root, out):
    hosts = [load_host(root, arch) for arch in ARCHES]
    body = ["# Exact integer products through an FP32 SGEMM interface", "",
            "A content check lets an ordinary FP32 matrix multiply use one BF16 product when all input values and partial sums "
            "are exactly representable. The registered Linux experiment compares the complete operation with qualified FP32 providers "
            "and domain-specific integer implementations on the same input buffers.", "", *map(summary, hosts), "",
            "### What the six fixtures measure", "",
            "Two signed synthetic products use values from −63 to 63 on a 4096³ cube and a cropped 1079×1553×1201 rectangle. "
            "Two copies of the rectangle add ½ to the first A value or the last B value. "
            "The real products compare handwritten digits across the original UCI test and training partitions. One computes "
            "64-feature dot products across 1,797×3,823 pairs. The other counts shared set pixels across 1,797×1,934 pairs "
            "of 1,024-pixel binary images. These are two representations from one collection. "
            "[UCI dataset](https://doi.org/10.24432/C50P49) · [Input transformations and hashes](source/exact/fixtures/data/ATTRIBUTION.md)", "",
            "The certificate requires integral inputs with magnitude at most 256, K ≤ 4,096 and K × max|A| × max|B| ≤ 2²⁴. "
            "A qualifying call scans the current inputs and uses vendor BF16 arithmetic through oneDNN or Arm Compute Library. "
            "Each rejected call delegates to the registered FP32 policy. Standalone COB has its own timing entry. "
            "Benchmark initialization fixes native availability for each tested geometry. Admission frequency on other applications remains unmeasured.", "",
            "A fresh process times its first multiply after library initialization, then its next multiply. "
            "Content inspection, allocations, conversions and packing inside each multiply are charged. "
            "Each ratio is peer time divided by candidate time, paired within a block and scheduling round. "
            "The reported speedup is the median of six paired ratios. Values above one favor the candidate. "
            "The registered improvement rule requires a median above 1.02× and at least five strict wins. "
            "The six pairs are within one VM per architecture. Two seeds change the synthetic inputs and leave both real datasets fixed.", "",
            "Every ordinary call is screened on every output against an exact binary64 reference and an absolute-product sum. "
            "Numerical qualification requires finite outputs, absolute error ≤0.002 and error ≤ K/(2²⁴−K) times the absolute-product sum. "
            "Exact qualification requires zero deviation. The fallback must also match a separate call to the same provider bit-for-bit. "
            "The known full-output hashes of both UCI products provide independent checks. [All individual peer ratios and raw medians](peer-comparisons.csv)", ""]
    for h in hosts:
        body.extend(write_host(h))
    body.extend(["## Reproduce the comparison", "",
                 "At the root of the evidence package, run `python3 -B verify.py` to replay the evidence offline. "
                 "To verify the original hosted ZIP members as well, supply `--archive-x86_64 path --archive-aarch64 path`. "
                 "The host receipts identify the original jobs and artifact digests.", ""])
    for h in hosts:
        p = h["receipt"]
        body.append(f"- {h['arch']} · [Run]({p.get('run_url') or p.get('url')}) · [Job {p['job_id']}]({p['job_url']}) · "
                    f"artifact {p['artifact_id']}, SHA-256 `{p['artifact_sha256']}`.")
    body.extend(["", f"[Frozen benchmark source and protocol]({REPO}/tree/c609245c8d7359b1e484c7d0896e3ad9a32a97a9/tools/world-rank/exact) · "
                 f"[Timed COB release source]({REPO}/tree/e4b7ce19cdf49f9175c86d3e91ea8d3a756eae9b)", ""])
    save_peer_csv(out.parent / "peer-comparisons.csv", hosts)
    out.write_text("\n".join(body))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package_root", type=Path)
    parser.add_argument("output_md", type=Path)
    args = parser.parse_args()
    render(args.package_root, args.output_md)
