"""Reconstruct precision-wave field comparisons from compact/raw CSVs with no hosted scorer dependency."""
import argparse
import csv
import hashlib
import json
import math
import re
import statistics
from pathlib import Path

PANEL_SHA='5f5735f5d4b464c0f665dd0595fb695384893ba593406c9b897131a1afe069e7'
PROTOCOL_SHA='485dbc8b05d57f264af682fb1d444449eaca1d3ef4efc220c528cc9631572c30'
PRODUCTION='f322a9ab58454762563b97323fdc5f29016cc39f'
SEEDS=(131658409,959813377)
FIXTURES=(('random',SEEDS[0]),('random',SEEDS[1]),('cancel',SEEDS[0]),('scaled',SEEDS[1]))
TRIALS=[(seed,rnd) for seed in SEEDS for rnd in (1,2,3)]
MIXED=('mixed1','mixed3','mixed6','mixed6-bands','mixed9','fused6-amx')
MED=statistics.median
GR='independent_oneshot independent_any fp32_oneshot fp32_any whole_any'.split()
def check(cond,details):
    if not cond:raise ValueError(details)
def read(root,name):
    with (root/name).open(newline='') as f:return list(csv.DictReader(f))
def load(root,name):return json.loads((root/name).read_text())
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def keyed(rows,columns):
    indexed={tuple(r[k] for k in columns):r for r in rows}
    check(len(indexed)==len(rows),'duplicate data '+str(columns))
    return indexed
def gm(v):return math.exp(sum(map(math.log,v))/len(v)) if v else None
def ordered_peer(values,names):
    return min(names,key=lambda n:MED(values[n]),default=None)
def metric(x,y):
    ratios=[b/a for a,b in zip(x,y,strict=True)]
    return dict(ratios=ratios,delta_ms=[1000*(b-a) for a,b in zip(x,y)],median=MED(ratios),
                raw_ratio=MED(y)/MED(x),wins=sum(y>x for x,y in zip(x,y)),ties=ratios.count(1),
                seed_medians=[MED(ratios[:3]),MED(ratios[3:])] if len(ratios)==6 else None,
                leave_one_out=[min(MED(ratios[:j]+ratios[j+1:]) for j in range(len(ratios))),
                              max(MED(ratios[:j]+ratios[j+1:]) for j in range(len(ratios)))])
def verify(raw):
    check(digest(raw/'panel.csv')==PANEL_SHA and digest(raw/'protocol.md')==PROTOCOL_SHA,'registration identity')
    measurement=load(raw,'measurement.json');cpu=measurement['cpu']; arch=measurement['architecture'];page=measurement['page']
    check((raw/'release-sha.txt').read_text().strip()==PRODUCTION and tuple(measurement['seeds'])==SEEDS,'release or seeds')
    cpuinfo=dict(tuple(part.strip() for part in ln.split(':',1)) for ln in (raw/'lscpu.txt').read_text().splitlines() if ':' in ln)
    check(cpuinfo['Architecture']==arch and cpu==int((raw/'cpu.txt').read_text()) and page==int((raw/'page-bytes.txt').read_text()),'host identity')
    panel=read(raw,'panel.csv'); registry={r['method']:r for r in read(raw,'methods.csv')}
    hosted=load(raw,'score.json');admit=load(raw,'admission.json');native=load(raw,'native-routes.json');mixed=list(MIXED)
    if arch=='aarch64':mixed.extend('arm-'+k for k in MIXED if k!='fused6-amx')
    roles={n:r['role'] for n,r in registry.items()};required={'cob-released','openblas','blasfeo','onednn-oneshot'}
    required.update({'aocl','mkl','mkl-jit'} if arch=='x86_64' else {'armpl'})
    check(all(roles[x]==('precision-reference' if x.removeprefix('arm-') in ('mixed1','mixed3') else 'mixed') for x in mixed),'mixed role roster')
    check(roles['onednn-cached-plan']=='independent-retained' and roles['cob-released']=='standalone','FP32 role roster')
    scores={};coverage={'accuracy_complete':0,'accuracy_checked':0,'warm_complete':0,'warm_checked':0}
    gold=keyed(read(raw,'goldens.csv'),['family','mode','seed'])
    quals=keyed(read(raw,'qualification.csv'),['family','method'])
    acc=keyed(read(raw,'accuracy.csv'),['family','method','mode','seed'])
    tim=keyed(read(raw,'timings.csv'),['family','method','seed','round'])
    check(len(quals)==len(registry)*8 and len(gold)==32 and len(panel)==8,'evidence cardinality')
    for idx,p in enumerate(panel):
        f=p['family']; m,n,k,la,lb,lc,ar,ac,br,bc,cr,cc=(int(p[key]) for key in 'm n k lda ldb ldc ar ac br bc cr cc'.split())
        for mode,seed in FIXTURES:
            g=gold[f,mode,str(seed)]
            check(int(g['bytes_each'])==8*m*n and int(g['checked'])==m*n and (int(g['cpu']),int(g['threads']))==(cpu,1) and g['weight_spots']==g['signed_spots']=='23' and all(0<=float(g[v])<=1e-9 for v in ('weight_spot_error','signed_spot_error')) and all(bool(re.fullmatch('[0-9a-f]{64}',g[v])) for v in ('a_sha256','b_sha256','reference_sha256','weight_sha256')),'oracle '+f)
        timed=[name for name in registry if quals[f,name]['timed']=='1']
        for ix,(seed,rnd) in enumerate(TRIALS):
            off=(idx+3*(rnd-1)+(5 if ix>=3 else 0))%max(1,len(timed));order=timed[off:]+timed[:off]
            if ix>=3:order.reverse()
            observed=[(name,tim[f,name,str(seed),str(rnd)]) for name in timed]
            check(all(int(r['position'])==order.index(name) for name,r in observed),'rotation '+f)
        strict=[];warm={};first={};excluded={};numeric={}
        for name,row in registry.items():
            a=[acc[f,name,mode,str(seed)] for mode,seed in FIXTURES if (f,name,mode,str(seed)) in acc]
            t=[tim[f,name,str(seed),str(rnd)] for seed,rnd in TRIALS if (f,name,str(seed),str(rnd)) in tim]
            check(len(a) in (0,4) and ((name in timed) == (len(t)==6)), 'fixtures '+f+' '+name)
            counts=dict(records=len(a),warm_records=len(t),protected=0,finite_failures=0,over_absolute=0,over_gamma=0,max_abs=0.,max_rho=0.)
            for is_timing,r in [(False,r) for r in a]+[(True,r) for r in t]:
                if r['structural']=='0':continue
                g=gold[f,r['mode'],r['seed']]
                check(r['a_sha256']==g['a_sha256'] and r['b_sha256']==g['b_sha256'] and bool(re.fullmatch('[0-9a-f]{64}',r['c_sha256'])), 'operand identity')
                expected_guards=((cr+m+2)*lc*4+page-1)//page*(page//4)-m*n
                check((int(r['checked']),int(r['guards']),int(r['cpu']),int(r['threads']))==(m*n,expected_guards,cpu,1) and
                      [int(r[z]) for z in ('a_mod64','b_mod64','c_mod64')]==[4*x%64 for x in (ar*la+ac,br*lb+bc,cr*lc+cc)],'view or CPU mismatch')
                e,rho,gamma=float(r['max_abs']),float(r['max_rho']),float(r['gamma'])
                na,ng,nf=(int(r[z]) for z in ('over_abs','over_gamma','nonfinite'))
                check(math.isclose(gamma,k/(2**24-k),rel_tol=1e-14) and all(0<=v<=m*n for v in (na,ng,nf)), 'all-cell numerics')
                numeric_ok=math.isfinite(e) and e<=.002 and math.isfinite(rho) and not(na or ng or nf)
                check((r['numerical']=='1')==numeric_ok,'FP64 admission')
                counts['protected']+=m*n;counts['finite_failures']+=nf;counts['over_absolute']+=na;counts['over_gamma']+=ng
                if math.isfinite(e):counts['max_abs']=max(counts['max_abs'],e)
                if math.isfinite(rho):counts['max_rho']=max(counts['max_rho'],rho)
                prefix='warm' if is_timing else 'accuracy';coverage[prefix+'_checked']+=m*n;coverage[prefix+'_complete']+=1
                check(float(r['first_s'])>0 and float(r['first_cpu_s'])>0,'first wall/caller clock')
                if is_timing:check(r['c_sha256']==acc[f,name,'random',r['seed']]['c_sha256'] and float(r['warm_s'])>0 and float(r['warm_cpu_s'])>0,'timed clock or warm overwrite')
                if name.startswith('onednn-'):
                    cache=int(name.endswith('cached-plan'))
                    check(r['implementation'] and not r['implementation'].lower().startswith('ref') and int(r['cached'])==cache and int(r['plans'])==(1+int(is_timing and not cache)),'strict direct oneDNN')
                if name in mixed:
                    nm=name.removeprefix('arm-');evidence=json.loads(r['route_evidence']);manifest=native[f][name]
                    expected=[] if name=='fused6-amx' else [3*k,2*k,k] if nm=='mixed6-bands' else [k]
                    terms=3 if nm=='mixed6-bands' else 6 if name=='fused6-amx' else int(nm.removeprefix('mixed'))
                    check(manifest['eligible'] is True and [x['stage'] for x in evidence]==(['FIRST','WARM'] if is_timing else ['FIRST']),'native measured calls')
                    for x in evidence:check(x['route']==1 and x['executions']==terms and x['depths']==expected and x['implementations']==manifest['impls'],'native method, implementation or depth order')
            numeric[name]=counts
            structural=bool(t) and len(a)==4 and all(y['structural']=='1' for y in a+t)
            strict_global=name not in mixed or (admit.get(name,{}).get('accuracy_qualified') is True and roles[name]=='mixed')
            qual=structural and all(y['numerical']=='1' for y in a+t) and strict_global
            if qual:strict.append(name)
            else:excluded[name]=quals[f,name]['reason'] or next((y['reason'] for y in t if y['numerical']!='1' or y['structural']!='1'),'excluded')
            if structural:
                warm[name]=[float(y['warm_s']) for y in t];first[name]=[float(y['first_s']) for y in t]
        check(set(strict)==set(hosted['cases'][f]['strict_qualified']),'hosted strict ranks '+f)
        field={};individual={}
        for tier in GR:
            if tier=='whole_any':group=strict
            elif tier.startswith('independent'):group=[x for x in strict if roles[x].startswith('independent')]
            else:group=[x for x in strict if x not in mixed]
            if tier.endswith('oneshot'):group=[x for x in group if roles[x]!='independent-retained']
            field[tier]=group;check(ordered_peer(warm,group)==hosted['cases'][f]['fastest'][tier],'whole-field leader '+f)
        for name in mixed:
            if name not in warm:continue
            comparisons={}
            for tier,group in field.items():
                peers=[x for x in group if x!=name]
                if not peers:continue
                leader=ordered_peer(warm,peers);cold=ordered_peer(first,peers)
                byblock=[min(peers,key=lambda x:MED(warm[x][3*i:3*i+3])) for i in range(2)]
                need=set(required)
                if tier.endswith('any'):need.add('onednn-cached-plan')
                if tier.startswith('independent'):need.discard('cob-released')
                missing=sorted(need-set(strict))
                measures={'warm':(leader,warm[name],warm[leader]),'first':(cold,first[name],first[cold])}
                for i,key in enumerate(byblock):measures['seed_'+str(SEEDS[i])]=(key,warm[name][3*i:3*i+3],warm[key][3*i:3*i+3])
                encoded={}
                for key,(peer,x,y) in measures.items():
                    comp=metric(x,y);comp['peer']=peer;comp['peer_median_ms']=1000*MED(y);comp['method_median_ms']=1000*MED(x)
                    comp['magnitude']={str(th):(not missing and name in strict and min(comp['raw_ratio'],comp['median'])>=th) for th in (1.5,2.0)};encoded[key]=comp
                w=encoded['warm'];passes=not missing and name in strict and w['median']>1.02 and w['raw_ratio']>1 and w['wins']>=5
                comparisons[tier]=dict(missing_required=missing,qualified=name in strict,passes=passes,measures=encoded)
                if name in strict:
                    old=hosted['cases'][f]['comparisons'][name]['tiers'][tier]
                    check(old['peer']==leader and old['peer_over_candidate']==w['ratios'] and old['passes']==passes,'hosted rank discrepancy '+name+' '+f)
                    if tier.startswith('fp32'):
                        for key,comp in encoded.items():
                            ho=old['magnitude'][key]
                            check(ho['peer']==comp['peer'] and ho['paired_ratios']==comp['ratios'] and all(ho['thresholds'][th]['reaches']==ok for th,ok in comp['magnitude'].items()),'magnitude disagreement')
            individual[name]=comparisons
        scores[f]=dict(shape=[m,n,k],layout=p['layout'],qualified=strict,median_ms={x:1000*MED(warm[x]) for x in warm},
                       first_ms={x:1000*MED(first[x]) for x in first},leaders={key:ordered_peer(warm,names) for key,names in field.items()},
                       exclusions=excluded,numeric=numeric,comparisons=individual)
    roll={}
    for name in mixed:
        roll[name]={}
        for tier in GR:
            cells=[v['comparisons'][name][tier] for v in scores.values() if tier in v['comparisons'].get(name,{})]
            eligible=[x for x in cells if x['qualified']]
            medians=[c['measures']['warm']['median'] for c in eligible]
            roll[name][tier]={'structural_layouts':len(cells),'strict_layouts':len(eligible),'paired_geomean':gm(medians),
                  'context_geomean':gm([c['measures']['warm']['median'] for c in cells]),'raw_wins':sum(c['measures']['warm']['raw_ratio']>1 for c in eligible),
                  'paired_wins':sum(c['measures']['warm']['wins'] for c in eligible),'passed_layouts':sum(c['passes'] for c in eligible),
                  'magnitude_counts':{measure:{str(th):sum(c['measures'][measure]['magnitude'][str(th)] for c in eligible) for th in (1.5,2.0)}
                                      for measure in ('warm','first',*('seed_'+str(s) for s in SEEDS))}}
            if name in hosted['gates'] and tier in hosted['gates'][name]:
                o=hosted['gates'][name][tier];r=roll[name][tier]
                check((o['covered'],o['raw_layout_wins'],o['paired_wins'],o['layouts_over_gate'])==(r['strict_layouts'],r['raw_wins'],r['paired_wins'],r['passed_layouts']),'hosted aggregate')
                if medians:check(math.isclose(o['ratio_geomean'],r['paired_geomean'],rel_tol=1e-12),'aggregate ratio')
    return dict(host=cpuinfo.get('Model name',arch),architecture=arch,cpu=cpu,release=PRODUCTION,benchmark=(raw/'benchmark-sha.txt').read_text().strip(),run=(raw/'run-id.txt').read_text().strip(),
                panel_sha256=PANEL_SHA,roles=roles,coverage=coverage,methods=list(registry),cases=scores,summary=roll)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('raw',type=Path);ap.add_argument('output',type=Path);args=ap.parse_args()
    args.output.write_text(json.dumps(verify(args.raw),indent=2,allow_nan=False)+'\n')
