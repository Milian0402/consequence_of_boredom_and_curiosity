"""Re-evaluate registered outputs and check separate native-implementation receipts."""
import csv
import hashlib
import importlib.util
import json
import math
from collections import Counter
from pathlib import Path
import re
import struct

REGISTER = "ec4bea33f96d3d7d6c13ff87a7f8cfa8e95a221662b1c708263867b70a4cbfc5"
POLICY = "90521489d614a9faf26c7147e00809b5b167fb5550c37ef15cdbb8ff6ff6d400"
ACL_DSO = "321fd6d02efe5d0cd1fa126f581d2addb5b36bdf7ab3c288c7b4d9c55bb5e8f0"
DNN_DSO = {"aarch64":"e8ec604abd0edb3c77656329bb76f64a5809d499ae4001c8182a9cb769e3287d",
           "x86_64":"9a6c34dd237ed50d5c6b26522ffa2f4f5135e4899a9fef03ea7ea20cba1e1a0a"}
ACL = "a64_interleaved_bf16fp32_mmla_8x12"
HEX = re.compile(r"[0-9a-f]{64}")
LABELS = {"1":"mixed1","3":"mixed3","6":"mixed6","9":"mixed9","16":"mixed6-bands"}

def req(ok, text):
    if not ok:
        raise ValueError(text)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_json(p):
    return json.loads(p.read_text())

def read_csv(p):
    with p.open(newline="") as f:
        return list(csv.DictReader(f))

def load_module(p):
    spec=importlib.util.spec_from_file_location("_precision_replay_"+p.stem,p)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def words(row,field):
    data=bytes.fromhex(row[field+"_words_le_hex"])
    req(len(data)==4*row["m"]*row["n"],"wrong output-word count")
    return list(struct.unpack("<%dI"%(len(data)//4),data))

def fingerprint(v):
    return hashlib.sha256(struct.pack("<%dI"%len(v),*v)).hexdigest()

def cls(word):
    mag=word&0x7fffffff
    return "finite" if mag<0x7f800000 else "nan" if mag>0x7f800000 else ("-inf" if word>>31 else "+inf")

def decode(v):
    e=(v>>23)&255; mantissa=v&0x7fffff
    req(e!=255,"finite operand expected")
    vabs=((mantissa+(1<<23))<<(e-1)) if e else mantissa
    return -(vabs<<149) if v>>31 else vabs<<149

def build_targets(src):
    folder=src/"accuracy"
    req(sha(folder/"registration.json")==REGISTER and sha(folder/"direct-control-policy.md")==POLICY,"wrong numerical registration or control screen")
    reg=read_json(folder/"registration.json")
    for name,expected in reg["sources"].items():
        req(sha(folder/name)==expected,"fixture source drift")
    fixtures=load_module(folder/"fixtures.py")
    oracle=load_module(folder/"oracle.py")
    targets={}
    for r in reg["inputs"]:
        case,seed=r["case"],r["seed"]
        m,n,k,a,b=fixtures.build(case,seed)
        req((r["m"],r["n"],r["k"],r["category"])==(m,n,k,fixtures.KINDS[case]) and
            (r["a_sha256"],r["b_sha256"])==(fingerprint(a),fingerprint(b)),"fixture payload changed")
        req((case,seed) not in targets,"duplicate registered fixture")
        targets[case,seed]=(r,oracle.exact(a,b,m,n,k))
    req(len(targets)==38 and len({key[0] for key in targets})==19 and len({key[1] for key in targets})==2,"strong-case roster")
    return targets

def case_evidence(row, targets, observed, control):
    counts=dict(class_fail=0,wrong_rounded=0,gamma_exceeded=0,abs_gt_002=0)
    squares=[0,0,0]; maxima=[0,0,0]; complete=True; k=row["k"]
    for (rounded,exact,abs_sum),got,base in zip(targets,observed,control,strict=True):
        fc=cls(rounded)
        if fc!=cls(got):
            counts["class_fail"]+=1
            counts["wrong_rounded"]+=1
            complete=False
            continue
        if fc!="finite":
            complete=False
            continue
        error=abs(decode(got)-exact)
        counts["wrong_rounded"]+=decode(rounded)!=decode(got)
        counts["gamma_exceeded"]+=error*((1<<24)-k)>k*abs_sum
        counts["abs_gt_002"]+=500*error>1<<298
        if cls(base)!="finite":
            complete=False
            continue
        direct=abs(decode(base)-exact)
        half=1<<max(148,abs(exact).bit_length()-25)
        for i,value in enumerate((error,direct,half)):
            maxima[i]=max(maxima[i],value)
            squares[i]+=value*value
    for name,num in counts.items():
        req(row[name]==num,"raw word/metric mismatch: "+name)
    maximum=maxima[0]<=2*max(maxima[1:]) if complete else None
    rms=squares[0]<=4*max(squares[1:]) if complete else None
    req((row["quality_max_pass"],row["quality_rms_pass"])==(maximum,rms),"independent quadratic/maximum decision differs")
    ratios=(maxima[0]/max(maxima[1:]),math.sqrt(squares[0]/max(squares[1:]))) if complete else (None,None)
    return dict(**counts,quality_max=maximum,quality_rms=rms,quality_max_ratio=ratios[0],quality_rms_ratio=ratios[1])

def strong_family(folder,targets,tag,core_hash=None):
    r=read_json(folder/"scores.json")
    req(r["registration"]==REGISTER and r["direct_policy_sha256"]==POLICY and r["backend"]==tag,"strong evidence identity")
    if core_hash:
        req(r["library_sha256"]==r["control_library_sha256"]==core_hash,"strong/control measured core binding")
    verdicts=read_json(folder/"verdicts.json")
    req(verdicts==r["verdicts"],"conflicting hosted verdict files")
    facts={}; direct_words={}; mode_rows={}
    for row in r["cases"]:
        which=(row["case"],row["seed"]); reg,oracle=targets[which]
        req(all(row[name]==reg[name] for name in ("case","seed","m","n","k","category")),"geometry/category differs")
        mode=row["mode"]
        current=mode_rows.setdefault(mode,{})
        req(which not in current,"duplicate numerical fixture")
        fact=dict(case=row["case"],seed=row["seed"],cat=row["category"],valid=row["returncode"]==0,
                  route=row["route"],reason=row["reason"],plans=row["plans"])
        if fact["valid"]:
            obs,ctrl=words(row,"output"),words(row,"control")
            req(fingerprint(obs)==row["output_sha256"],"incorrect native output hash")
            canon=[0x7fc00000 if cls(v)=="nan" else 0 if v&0x7fffffff==0 else v for v in obs]
            req(fingerprint(canon)==row["semantic_sha256"],"incorrect normalized output hash")
            ctrl_hash=fingerprint(ctrl)
            req(direct_words.setdefault(which,ctrl_hash)==ctrl_hash,"direct output changed between component modes")
            fact.update(case_evidence(row,oracle,obs,ctrl))
            if mode in LABELS:
                route=row["route"]
                if route==1:
                    if tag=="fused-amx":
                        req(not row["plans"] and row["primitive_calls"]==6,"unexpected fused strong route")
                    else:
                        p=row["plans"]
                        expected=[3*row["k"],2*row["k"],row["k"]] if mode=="16" else [row["k"]]
                        req([x["k"] for x in p]==expected and row["primitive_calls"]==(3 if mode=="16" else int(mode)),"incomplete reported component path")
                elif route==2:
                    req(not row["plans"] and row["primitive_calls"]==0 and row["reason"]=="fp64-range-rescue","invalid rescue receipt")
                else:
                    req(route==0 and row["k"]==0 and row["reason"]=="zero-k","unexpected non-component route")
        current[which]=fact

    for mode,rr in mode_rows.items():
        req(set(rr)==set(targets),"incomplete fixture geometry/seed grid")
        all_rows=list(rr.values())
        def every(select,predicate):
            subset=[v for v in all_rows if select(v)]
            return all(predicate(v) for v in subset) if subset and all(v["valid"] for v in subset) else None
        normal=lambda x:x["cat"]=="normal"
        cat=lambda kind:lambda x:x["cat"]==kind
        failures=lambda x:x["class_fail"]==0
        normal_rows=[v for v in all_rows if normal(v)]
        v=dict(complete=all(x["valid"] for x in all_rows),
               normal_envelope=every(normal,lambda x:failures(x) and x["gamma_exceeded"]==0),
               hk_exact=every(lambda x:x["case"].startswith("hk-"),lambda x:x["wrong_rounded"]==0),
               zero_overwrite=every(cat("zero"),lambda x:x["wrong_rounded"]==0),
               range_classes=every(cat("range"),failures),exceptional_classes=every(cat("nonfinite"),failures))
        primary=all(v.values())
        available=all(x["valid"] and x.get("quality_max") is not None and x.get("quality_rms") is not None for x in normal_rows)
        direct=all(x["quality_max"] and x["quality_rms"] for x in normal_rows) if available else None
        v.update(accuracy_gate=primary,direct_quality=direct,matched_direct_accuracy=(primary and direct is True))
        hosted=verdicts[mode]
        req(all(hosted[key]==val for key,val in v.items()),"hosted strong outcome differs for "+str(mode))
        v.update(covered=len(all_rows),output_cells_checked=sum(targets[(x["case"],x["seed"])][0]["m"]*targets[(x["case"],x["seed"])][0]["n"] for x in all_rows if x["valid"]),
                 normal_breaches=[{"case":x["case"],"seed":x["seed"],"max":x.get("quality_max"),"rms":x.get("quality_rms")} for x in normal_rows if x["valid"] and x.get("quality_max") is not None and not (x.get("quality_max") and x.get("quality_rms"))],
                 routes={c:dict(Counter(str(x["route"]) for x in all_rows if x["cat"]==c)) for c in ("normal","zero","range","nonfinite")},
                 error_cell_counts={c:{metric:sum(x.get(metric,0) for x in all_rows if x["cat"]==c and x["valid"])
                                    for metric in ("class_fail","wrong_rounded","abs_gt_002","gamma_exceeded")}
                                    for c in ("normal","zero","range","nonfinite")},
                 reported_native_descriptor_cases=sum(x["valid"] and x["route"]==1 and bool(x["plans"]) and all(y["native"]==1 for y in x["plans"]) for x in all_rows),
                 failed_implementation_cases=sum(not x["valid"] for x in all_rows),
                 reason_counts=dict(Counter(x["reason"] for x in all_rows)))
        req(v["normal_breaches"]==hosted["direct_quality_breaches"],"direct quality breach attribution")
        route_pass=every(normal,lambda x:x["route"]==1) if any(isinstance(x["route"],int) for x in all_rows) else None
        req(v["routes"]["normal"]==hosted["ordinary_route_counts"] and route_pass==hosted["ordinary_component_route"],
            "strong-fixture component/fallback routing disagreement")
        v["ordinary_component_route"]=route_pass
        worst={}
        for metric in ("quality_max_ratio","quality_rms_ratio"):
            ordinary=[row for row in normal_rows if row.get(metric) is not None]
            if ordinary:
                row=max(ordinary,key=lambda x:x[metric])
                worst[metric]=dict(case=row["case"],seed=row["seed"],ratio=row[metric],threshold=2)
        v["worst_normal_errors_relative_to_control_or_half_ulp"]=worst
        facts[mode]=v
    return facts,direct_words

def hashes(path):
    result={}
    for line in path.read_text().splitlines():
        match=re.fullmatch(r"([0-9a-f]{64})\s+\*?(.+)",line)
        if match:
            name=Path(match[2]).name
            req(name not in result or result[name]==match[1],"conflicting compiled digest")
            result[name]=match[1]
    return result

def raw_records(lines,tag):
    return [v.split(",")[1:] for v in lines if v.startswith(tag+",")]

def probe_outputs(lines,dims,cpu):
    m,n,_,_,_,ldc=dims
    rows=raw_records(lines,"BF16_EXEC")
    req(len(rows)==2 and raw_records(lines,"BF16_LIFE")==[["1","2","1"]],"two changed-input executions and lifecycle required")
    for i,data in enumerate(rows):
        expected=[i,0,m*n,7+3*i+m*ldc+17-m*n,0,0,0,1,1,cpu,i+1]
        req([float(x) for x in data]==expected,"incorrect native full-output or thread/guard witness")

def depth_proof(raw,path,r,dims,cpu,arch,tag):
    req(r.get("emulated") is not True,"emulated receipt in native trial")
    req(r["shape_and_strides"]==dims,"descriptor shape/stride differs")
    req(r.get("affinity_cpu",cpu)==cpu and r.get("architecture",arch)==arch,"descriptor host mismatch")
    m,n,k,*_=dims
    info=dict(eligible=bool(r["eligible"]),route=r.get("route",""),implementation=r.get("implementation",""),
              reason=r.get("reason",""),receipt_sha256=sha(path),checked_outputs=r.get("checked_outputs",0))
    if tag=="arm":
        ident=read_json(raw/"build/acl-identity.json")
        req(r.get("source_identity",ident)==ident and ident["acl_dso_sha256"]==ACL_DSO,"ACL provider identity")
        req(r.get("build_receipt_sha256",sha(raw/"build/acl-identity.json"))==sha(raw/"build/acl-identity.json"),"ACL receipt identity")
        info["build_dso_sha256"]=ACL_DSO
        if not info["eligible"]:
            return info
        req(r.get("source_identity")==ident and r.get("build_receipt_sha256")==sha(raw/"build/acl-identity.json"),"missing active ACL library/call receipt")
        info.update(dso_sha256=ACL_DSO,bridge_sha256=ident["sha256"]["libacl_bf16_backend.so"])
        req((arch,r["implementation"],r["route"])==("aarch64",ACL,"arm-acl-neon-bfmmla") and
            {"asimd","bf16"}<=set(r["host_relevant_features"]),"incorrect ACL kernel/CPU")
        disasm=raw/"build/acl-kernel.txt"
        req(sha(disasm)==r["kernel_disassembly_sha256"]==ident["sha256"]["acl-kernel.txt"],"disassembled ELF symbol digest")
        assembly=disasm.read_text()
        req(re.findall(r"^\s*[0-9a-f]+ <([^>]+)>:$",assembly,re.M)==[ident["kernel_symbol"]],"unexpected disassembled functions")
        sites=len(re.findall(r"\bbfmmla\s+v",assembly,re.I))
        req(sites>0 and sites==r["opcode_sites"]==ident["bfmmla_static_count"],"actual ACL code instruction sites")
        fold=lambda a,b:(a+b-1)//b
        ab,bb,kp=fold(m,8),fold(n,12),4*fold(k,4)
        per=fold(ab,8)*fold(bb,8)
        for key,file in (("ordinary","acl-probe"),("trace","acl-probe-trace")):
            run=r[key]; req(run["probe_sha256"]==ident["sha256"][file],"probe build identity")
            logs=run["raw_worker_records"]; probe_outputs(logs,dims,cpu)
            req(raw_records(logs,"BF16_PLAN")==[["0",ACL,"arm-acl-neon-bfmmla","1"]],"ACL typed plan")
            hits=raw_records(logs,"ACL_BF16_KERNEL")
            req(len(hits)==(2 if key=="trace" else 0),"ABI boundary observed on diagnostic only")
            for h in hits:
                fields=dict(x.split("=",1) for x in h)
                exp=dict(calls=per,abytes=ab*8*kp*2,bbytes=bb*12*kp*2,cbytes=min(ab,8)*min(bb,8)*384,
                         allocations=2,m=m,n=n,k=k,ablocks=ab,bblocks=bb,kp=kp,planbytes=96)
                req(fields.pop("name")==ACL and {k:int(v) for k,v in fields.items()}==exp,"ABI kernel arguments/allocations")
        req(r["checked_outputs"]==4*m*n,"ACL output coverage")
        info.update(opcode_sites=sites,actual_calls_per_execution=per,trace_binary_sha256=ident["sha256"]["libacl_bf16_trace.so"])
        return info

    build=raw/"build/bf16-build.txt"
    receipt=hashes(build)
    req(r.get("mapped_onednn_sha256",DNN_DSO[arch])==DNN_DSO[arch] and
        "libdnnl_sha256="+DNN_DSO[arch] in build.read_text(),"pinned oneDNN provider")
    for key,file in (("bridge_sha256","libbf16_backend.so"),("probe_sha256","bf16-probe")):
        req(r.get(key,receipt[file])==receipt[file],"oneDNN compiled receipt")
        info[key]=receipt[file]
    req(r.get("build_receipt_sha256",sha(build))==sha(build),"oneDNN build fingerprint drift")
    info["build_dso_sha256"]=DNN_DSO[arch]
    if r.get("mapped_onednn_sha256"):
        info["dso_sha256"]=r["mapped_onednn_sha256"]
    if not info["eligible"]:
        if r.get("status")==0:
            plan=raw_records(r["raw_worker_records"],"BF16_PLAN")
            req(len(plan)==1 and plan[0][1:3]==[r["implementation"],r["route"]],"omitted descriptor identity")
        return info
    req(r["native_descriptor"] and r["status"]==0 and r["returncode"]==0 and r["mapped_onednn_sha256"]==DNN_DSO[arch],"actual native status")
    req(raw_records(r["raw_worker_records"],"BF16_PLAN")==[["0",r["implementation"],r["route"],"1"]],"typed native descriptor")
    probe_outputs(r["raw_worker_records"],dims,cpu)
    req(r["checked_outputs"]==2*m*n and any("runtime:sequential,nthr:1" in s for s in r["verbose_runtime_records"]),"sequential native oneDNN")
    verbose=r["verbose_exec_records"]; req(len(verbose)==2,"two primitive logs")
    for line in verbose:
        req(","+r["implementation"]+"," in line and f",{m}x{k}:{k}x{n}," in line and
            all(re.search(r"\b"+name+"[:_]"+typ+r"\b",line) for name,typ in (("src","bf16"),("wei","bf16"),("dst","f32"))),
            "oneDNN actual geometry/datatypes")
    match=(r"\btdpbf16ps\b" if arch=="x86_64" else r"\b(?:bfmmla|bfdot)\b")
    kernels=[x for x in r["jit_bf16_instructions"] if re.match(r"dnnl_dump_cpu_jit_(brgemm|bf16_matmul)",x["kernel_file"])
             and HEX.fullmatch(x["sha256"]) and x["bytes"]>0 and x["instruction_sites"]>0 and re.search(match,x["instruction_example"],re.I)]
    req(kernels and ({"amx_tile","amx_bf16"} if arch=="x86_64" else {"sve","svebf16"})<=set(r["host_relevant_features"]),"computational kernel code or CPU mismatch")
    info["disassembled_jit_sha256"]=[x["sha256"] for x in kernels]
    info["instruction_examples"]=[x["instruction_example"] for x in kernels]
    return info

def fused_proof(raw,path,r,g,cpu,arch,products):
    req(arch=="x86_64","unexpected architecture for AMX")
    info=dict(eligible=bool(r["eligible"]),reason=r.get("reason",""),receipt_sha256=sha(path),route=r.get("route",""))
    if not info["eligible"]:return info
    m,n,k,ldc,cr=(int(g[f]) for f in ("m","n","k","ldc","cr"))
    tiles=((m+15)//16)*((n+15)//16); blocks=tiles*((k+31)//32)
    req([r[f] for f in ("tiles","blocks","dot_instructions","output_cells","outside_C_cells","mismatches","input_or_padding_changes","cpu","threads")]==
        [tiles,blocks,6*blocks,m*n,(cr+m+2)*ldc+32-m*n,0,0,cpu,1],"fused activity and guarded numerical extent")
    iso=raw/"build/fused-instructions.txt"
    req(len(re.findall(r"\btdpbf16ps\b",iso.read_text(),re.I))>=6,"fused ordinary computation opcodes")
    req("amx_bf16" in (raw/"lscpu.txt").read_text() and "amx_tile" in (raw/"lscpu.txt").read_text(),"AMX host flags")
    log=path.with_suffix(".log")
    if log.exists():
        req([json.loads(line) for line in log.read_text().splitlines() if line.startswith("{")]==[r],"hosted trace/original probe mismatch")
    info.update(tiles=tiles,depth_blocks=blocks,diagnostic_dot_updates=6*blocks,
                ordinary_sha256=products["fused6-amx.so"],trace_sha256=products["fused6-amx.trace.so"],
                opcode_listing_sha256=sha(iso),checked_outputs=m*n)
    return info

def audit(raw,benchmark_source):
    raw,source=Path(raw),Path(benchmark_source)
    if not (raw/"measurement.json").exists() and (raw/"precision/measurement.json").exists():raw=raw/"precision"
    src=next((p for p in (source,source/"precision",source/"tools/world-rank/precision") if (p/"accuracy/registration.json").is_file()),None)
    req(src is not None,"frozen precision sources required for strong verification")
    manifest={}
    for line in (raw/"study-sources.sha256").read_text().splitlines():
        h,name=line.split(maxsplit=1); name=name.strip()
        if name.startswith("precision/"):
            p=src/name.removeprefix("precision/")
            req(not any(part==".." for part in Path(name).parts) and not Path(name).is_absolute(),"unsafe relative source path")
            if p.is_file():
                req(sha(p)==h,"benchmark source drift: "+name)
                manifest[name]=h
    for name in ("accuracy/fixtures.py","accuracy/oracle.py","accuracy/registration.json","accuracy/direct-control-policy.md",
                 "core/fp32.c","core/build-plugins.sh","core/fused_probe.c","core/admit.py","core/plugin.c",
                 "backend/qualify.py","acl-backend/backend.c","acl-backend/qualify.py","fused-amx/amx_compute.c",
                 "fused-amx/amx_fused6.c","study.py"):
        req("precision/"+name in manifest,"missing frozen source for "+name)
    targets=build_targets(src)
    measurement=read_json(raw/"measurement.json");arch,cpu=measurement["architecture"],measurement["cpu"]
    req(arch in DNN_DSO,"unknown native CPU")
    adapters={r["method"]:r for r in read_csv(raw/"methods.csv")}
    reg=read_json(raw/"admission.json")
    native=read_json(raw/"native-routes.json")
    panel={r["family"]:r for r in read_csv(raw/"panel.csv")}
    products=hashes(raw/"build/products.sha256")
    rosters={"onednn":{v:k for k,v in LABELS.items()}}
    if arch=="aarch64": rosters["arm"]={"arm-"+v:k for k,v in LABELS.items()}
    else: rosters["fused-amx"]={"fused6-amx":"6"}
    strong={}; shapes={}; cores={}; proofs={}; direct={}; shared_mismatches=[]
    for tag,methods in rosters.items():
        family=raw/"precision-accuracy"/tag
        name={"onednn":"onednn-core.so","arm":"arm-core.so","fused-amx":"fused6-amx.so"}[tag]
        if (family/"scores.json").exists():
            cores[tag]=products[name]
            scores,controls=strong_family(family,targets,tag,cores[tag])
            req(set(scores)==set(methods.values()),"wrong registered numerical scheme roster")
            for key,h in controls.items():
                if direct.setdefault(key,h)!=h:shared_mismatches.append([tag,*key])
        else: scores={}
        for method,mode in methods.items():
            declared=reg[method];measured=adapters[method]
            if measured["available"]=="1":
                req(measured["adapter_sha256"]==products[method+".so"],"ordinary adapter SHA mismatch")
            found=scores.get(mode)
            expected=bool(found and method.removeprefix("arm-") not in ("mixed1","mixed3") and found["matched_direct_accuracy"])
            req(expected==declared["accuracy_qualified"],"hosted global numerical admission")
            strong[method]=dict(available=measured["available"]=="1",strict_numerical_admission=expected,reason=declared["reason"],verdict=found,
                                core_sha256=cores.get(tag),adapter_sha256=measured["adapter_sha256"])
            for family,g in panel.items():
                entry=native[family][method];k=int(g["k"])
                depths=[] if tag=="fused-amx" else [3*k,2*k,k] if mode=="16" else [k]
                req(entry["required_depths"]==depths,"required native K depths mismatch")
                checks=[]
                witnesses=entry.get("witnesses",[])
                expected_paths=([f"native-bf16/{tag}-{family}.json"] if tag=="fused-amx" else
                                [f"native-bf16/{tag}-{family}-k{d}.json" for d in depths])
                req(not witnesses or witnesses==expected_paths,"trace files do not match the registered geometry and depths")
                for i,relative in enumerate(witnesses):
                    path=Path(relative)
                    req(path.parent.as_posix()=="native-bf16" and not path.is_absolute(),"invalid witness path")
                    if relative not in proofs:
                        p=raw/path;r=read_json(p)
                        if tag=="fused-amx":
                            info=fused_proof(raw,p,r,g,cpu,arch,products)
                        else:
                            d=depths[i];m,n=int(g["m"]),int(g["n"])
                            info=depth_proof(raw,p,r,[m,n,d,d,n,n],cpu,arch,tag)
                        proofs[relative]=info
                    checks.append(proofs[relative])
                eligible=(len(checks)==(1 if tag=="fused-amx" else len(depths)) and all(w["eligible"] for w in checks))
                req(eligible==entry["eligible"],"enrolled geometry disagrees with hardware proof")
                if eligible and tag!="fused-amx":
                    req(entry["impls"]==[v["implementation"] for v in checks],"registered runtime does not match qualifying primitive")
                shapes.setdefault(family,{})[method]=dict(eligible=eligible,required_depths=depths,reason=entry["reason"],
                                                          proofs=entry.get("witnesses",[]),observations_verified=0)
    for table in ("accuracy.csv","timings.csv"):
        for row in read_csv(raw/table):
            method=row["method"]
            if method not in strong or row["structural"]!="1":continue
            check=shapes[row["family"]][method]
            req(check["eligible"],"ordinary data marked structural on unverified path")
            stages=json.loads(row["route_evidence"])
            req([s["stage"] for s in stages]==(["FIRST","WARM"] if table=="timings.csv" else ["FIRST"]),"ordinary call presence differs")
            impls=[proofs[v].get("implementation","") for v in check["proofs"]] if method!="fused6-amx" else []
            terms=3 if method.endswith("-bands") else 6 if method=="fused6-amx" else int(method[-1])
            for s in stages:
                req(s["route"]==1 and s["executions"]==terms and s["depths"]==check["required_depths"] and s["implementations"]==impls,
                    "ordinary binary called a different implementation or K depth")
            check["observations_verified"]+=1
    return dict(architecture=arch,cpu=cpu,strong=strong,shapes=shapes,proofs=proofs,
        identities=dict(frozen_registration=REGISTER,direct_control_policy=POLICY,compiled=products,cores=cores,
                        verified_source_files=len(manifest),source_manifest=sha(raw/"study-sources.sha256")),
        direct_cross_library_differences=shared_mismatches,
        interpretation="Every successful adversarial output and matched direct output is replayed from recorded FP32 bits. Architecture-specific traces or generated-code receipts qualify the panel geometries. Such receipts describe separate executions; no hardware retired-instruction counter was collected.")
