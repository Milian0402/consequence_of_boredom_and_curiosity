"""Describe a terminal host with missing evidence without inferring absent timing observations."""
import csv
import json
from pathlib import Path

def read(path):
    if not path.exists():return []
    with path.open(newline='') as f:return list(csv.DictReader(f))
def partial(raw,receipt):
    model=receipt['arch']
    if (raw/'lscpu.txt').exists():
        lines=[s.split(':',1)[1].strip() for s in (raw/'lscpu.txt').read_text().splitlines() if s.startswith('Model name:')]
        if lines:model=lines[0]
    a=read(raw/'accuracy.csv');t=read(raw/'timings.csv')
    reg=read(raw/'methods.csv');q=read(raw/'qualification.csv')
    count=lambda rows:sum(r.get('structural')=='1' for r in rows)
    exact={}
    for family in (raw/'precision-accuracy').glob('*/verdicts.json'):
        exact[family.parent.name]=json.loads(family.read_text())
    return dict(incomplete=True,host=model,architecture=receipt['arch'],coverage={'accuracy_rows':len(a),'structural_accuracy':count(a),
        'timing_rows':len(t),'structural_timing':count(t),'qualification_rows':len(q)},
        fully_observed_roster=[r['method'] for r in reg],registered_layouts=8,qualified_layouts=None,
        score_missing=not (raw/'score.json').exists(),exact_provider_verdicts=exact,
        terminal_steps=receipt.get('steps',[]))
