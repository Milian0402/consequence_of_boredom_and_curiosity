"""Bind the compact numeric evidence to a previously authenticated hosted ZIP and source commit."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def h(b):return hashlib.sha256(b).hexdigest()
def check(ok,msg):
    if not ok:raise ValueError(msg)
def verify(original,receipt,files,raw):
    info=json.loads(receipt.read_text());members=json.loads(files.read_text())
    check(str(info['artifact_sha256']).removeprefix('sha256:')==sha(original) and original.stat().st_size==int(info['bytes']),'official ZIP integrity')
    with zipfile.ZipFile(original) as z:
        check(z.testzip() is None,'ZIP CRC failure')
        names=[i.filename for i in z.infolist() if not i.is_dir()]
        check(len(set(names))==len(names)==len(members)==int(info['members']) and set(names)==set(members),'member roster')
        for name in names:
            contents=z.read(name);check(h(contents)==members[name] and (raw/name).read_bytes()==contents,'official member mismatch: '+name)
    for name,expected in [('run-id.txt',str(info['run'])),('benchmark-sha.txt',info['benchmark_sha'])]:
        if (raw/name).exists():check((raw/name).read_text().strip()==expected,'unbound benchmark source')
        else:check(info['status']=='failure' and info.get('source_sha')==info['benchmark_sha'],'missing job and benchmark source')
    return info
def verify_compact(root,original=None):
    receipt=json.loads((root/'github.json').read_text());members=json.loads((root/'members.json').read_text())
    if original:check(sha(original)==receipt['artifact_sha256'].removeprefix('sha256:'),'wrong original ZIP')
    for rel,proof in members.items():
        check(sha(root/'raw'/rel)==proof['published'],'published member differs: '+rel)
        if original:
            with zipfile.ZipFile(original) as z:check(h(z.read(rel))==proof['original'],'original member differs: '+rel)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('host',type=Path);ap.add_argument('--original',type=Path);a=ap.parse_args()
    verify_compact(a.host,a.original);print('Verified compact member digests'+(' and original archive' if a.original else ''))
