# Single-thread FP32 multiplication using BF16 hardware

Across the 2 completed native CPU panels, the strict mixed-precision candidates qualified for 56 method/layout comparisons. They won **0 of 336 paired warm calls** against the fastest qualified complete-call FP32 rival, and 0 method/layout comparisons passed the registered speed threshold. Each CPU and candidate is scored separately below.

- **Xeon 6975P-C** — oneDNN six-term 0.33× across 8/8, `fused6-amx` 0.67× across 8/8, the one-term reduced-precision control averaged 1.10× and failed FP32 accuracy.
- **Neoverse-N2** — oneDNN BF16 had no qualified native hardware path on these eight layouts, `arm-mixed6` 0.41× across 8/8, the one-term reduced-precision control averaged 2.09× and failed FP32 accuracy.

## Xeon 6975P-C

The largest paired warm speed ratio among accuracy-qualified mixed methods was **0.87×**, for `fused6-amx` on `square-1024` against `mkl-jit`. The registered per-layout test passed in 0 method/layout comparisons. Each method has eight registered layouts.

Run 45717780617, attempt 1, job 139568265376. Pinned logical CPU 0. The eight layouts produced 728 structurally valid accuracy observations and 1,092 structurally valid warm observations. Each observation checked every output against signed FP64 and the componentwise magnitude reference. [Hosted job](https://github.com/Milian0402/consequence_of_boredom_and_curiosity/actions/runs/45717780617/job/139568265376)

| Mixed method | Structurally timed / 8 | Strict accuracy / 8 | Warm ratio vs best complete-call FP32 | Raw wins / qualified layouts | Repeatability test wins / 8 | ≥1.5× warm / first | ≥2× warm / first |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `mixed1` | 8 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `mixed3` | 8 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `mixed6` | 8 | 8 | 0.33× | 0/8 | 0 | 0 / 0 | 0 / 0 |
| `mixed6-bands` | 8 | 8 | 0.24× | 0/8 | 0 | 0 / 0 | 0 / 0 |
| `mixed9` | 8 | 8 | 0.26× | 0/8 | 0 | 0 / 0 | 0 / 0 |
| `fused6-amx` | 8 | 8 | 0.67× | 0/8 | 0 | 0 / 0 | 0 / 0 |

Geometric means weight qualified layouts equally. Each per-layout speed ratio is the median of six paired FP32-rival/mixed warm times. The two magnitude columns use the fastest FP32 method in the corresponding warm or first-call observations. Both the median pair ratio and the ratio of raw medians must reach the threshold, with required comparator coverage. Separate seed-block tallies and prepared-plan comparisons are in the evidence.

| Layout, M × N × K | Fastest ordinary FP32, warm ms | Fastest strict method including retained plans, warm ms | Fastest native mixed timing, warm ms | Paired warm ratio vs ordinary FP32 | Accuracy tier of that mixed result |
| --- | --- | --- | --- | ---: | --- |
| 512 × 512 × 512 | `aocl`, 1.29 | `aocl`, 1.29 | `fused6-amx`, 1.96 | 0.66× | accuracy-qualified |
| 1024 × 1024 × 1024 | `mkl-jit`, 10.03 | `mkl-jit`, 10.03 | `mixed1`, 9.06 | 1.11× | reduced precision |
| 2048 × 2048 × 2048 | `mkl-jit`, 78.03 | `mkl-jit`, 78.03 | `mixed1`, 43.41 | 1.81× | reduced precision |
| 4096 × 4096 × 4096 | `release-mkl-aligned-two`, 590.43 | `release-mkl-aligned-two`, 590.43 | `mixed1`, 318.81 | 1.84× | reduced precision |
| 1537 × 2053 × 1789 | `openblas`, 52.35 | `openblas`, 52.35 | `mixed1`, 32.70 | 1.60× | reduced precision |
| 2039 × 2969 × 3367 | `mkl-jit`, 186.49 | `mkl-jit`, 186.49 | `mixed1`, 144.40 | 1.30× | reduced precision |
| 159 × 4093 × 510 | `mkl-jit`, 3.13 | `mkl-jit`, 3.13 | `fused6-amx`, 7.21 | 0.43× | accuracy-qualified |
| 1793 × 1151 × 2779 | `openblas`, 53.64 | `openblas`, 53.64 | `mixed1`, 42.58 | 1.27× | reduced precision |

The fastest native timing column includes reduced-precision methods. It describes the cost of the hardware path and carries the accuracy classification in the final column. The preregistered six-product primary is `mixed6`. `mixed6-bands`, `mixed9`, Intel’s fused AMX kernel, and Arm’s ACL-backed methods each have their own registered score.

| Contextual method | Warm paired ratio on measured layouts | Layouts measured | Cells outside gamma / absolute limit across bounded observations |
| --- | ---: | ---: | ---: |
| `mixed1` | 1.10× | 8/8 | 17,235,753 / 293,578,657 |
| `mixed3` | 0.55× | 8/8 | 0 / 0 |
| `mixed6` | 0.33× | 8/8 | 0 / 0 |
| `mixed6-bands` | 0.24× | 8/8 | 0 / 0 |
| `mixed9` | 0.26× | 8/8 | 0 / 0 |
| `fused6-amx` | 0.67× | 8/8 | 0 / 0 |

FP32 field exclusions comprised `blasfeo` on 2/8, `tblis-ab-1` on 2/8, `tblis-ab-2` on 2/8.

The native adversarial panel independently compares actual output words and the released FP32 control to exact integer dot products. It tests 19 input families at two seeds, including finite cancellation, BF16 rounding boundaries, exact HK products, zero depth, range extremes and nonfinite behavior. Detailed per-method verdicts, failed input families and native versus rescue counts are retained in the evidence.

| Hardware method | Completed adversarial records / 38 | Normal inputs inside gamma | Exact HK dyadics | Range and special classes | Direct FP32 max/RMS quality |
| --- | ---: | --- | --- | --- | --- |
| `mixed1` | 38 | fail | pass | fail | fail |
| `mixed3` | 38 | fail | pass | pass | fail |
| `mixed6` | 38 | pass | pass | pass | pass |
| `mixed6-bands` | 38 | pass | pass | pass | pass |
| `mixed9` | 38 | pass | pass | pass | pass |
| `fused6-amx` | 38 | pass | pass | pass | pass |

The direct-quality column compares maximum and RMS absolute errors against ordinary released FP32 on the same inputs with the preregistered half-ULP allowance. It can reject a mixed method that passed every bounded large-matrix accuracy check. The source and per-case bit patterns let the offline verifier reconstruct this decision.

## Neoverse-N2

The largest paired warm speed ratio among accuracy-qualified mixed methods was **0.47×**, for `arm-mixed6` on `odd-cropped` against `release-openblas-aligned-two`. The registered per-layout test passed in 0 method/layout comparisons. Each method has eight registered layouts.

Run 45717780617, attempt 1, job 139568265251. Pinned logical CPU 0. The eight layouts produced 568 structurally valid accuracy observations and 852 structurally valid warm observations. Each observation checked every output against signed FP64 and the componentwise magnitude reference. [Hosted job](https://github.com/Milian0402/consequence_of_boredom_and_curiosity/actions/runs/45717780617/job/139568265251)

| Mixed method | Structurally timed / 8 | Strict accuracy / 8 | Warm ratio vs best complete-call FP32 | Raw wins / qualified layouts | Repeatability test wins / 8 | ≥1.5× warm / first | ≥2× warm / first |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `mixed1` | 0 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `mixed3` | 0 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `mixed6` | 0 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `mixed6-bands` | 0 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `mixed9` | 0 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `fused6-amx` | 0 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `arm-mixed1` | 8 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `arm-mixed3` | 8 | 0 | — | 0/0 | 0 | 0 / 0 | 0 / 0 |
| `arm-mixed6` | 8 | 8 | 0.41× | 0/8 | 0 | 0 / 0 | 0 / 0 |
| `arm-mixed6-bands` | 8 | 8 | 0.39× | 0/8 | 0 | 0 / 0 | 0 / 0 |
| `arm-mixed9` | 8 | 8 | 0.30× | 0/8 | 0 | 0 / 0 | 0 / 0 |

Geometric means weight qualified layouts equally. Each per-layout speed ratio is the median of six paired FP32-rival/mixed warm times. The two magnitude columns use the fastest FP32 method in the corresponding warm or first-call observations. Both the median pair ratio and the ratio of raw medians must reach the threshold, with required comparator coverage. Separate seed-block tallies and prepared-plan comparisons are in the evidence.

| Layout, M × N × K | Fastest ordinary FP32, warm ms | Fastest strict method including retained plans, warm ms | Fastest native mixed timing, warm ms | Paired warm ratio vs ordinary FP32 | Accuracy tier of that mixed result |
| --- | --- | --- | --- | ---: | --- |
| 512 × 512 × 512 | `blasfeo`, 5.25 | `blasfeo`, 5.25 | `arm-mixed1`, 3.18 | 1.66× | reduced precision |
| 1024 × 1024 × 1024 | `cob-released-hk15`, 40.34 | `cob-released-hk15`, 40.34 | `arm-mixed1`, 18.75 | 2.15× | reduced precision |
| 2048 × 2048 × 2048 | `fastmmw-1536`, 306.54 | `fastmmw-1536`, 306.54 | `arm-mixed1`, 121.52 | 2.52× | reduced precision |
| 4096 × 4096 × 4096 | `fastmmw-1536`, 2166.11 | `fastmmw-1536`, 2166.11 | `arm-mixed1`, 905.03 | 2.40× | reduced precision |
| 1537 × 2053 × 1789 | `release-openblas-aligned-two`, 207.27 | `release-openblas-aligned-two`, 207.27 | `arm-mixed1`, 83.73 | 2.47× | reduced precision |
| 2039 × 2969 × 3367 | `release-openblas-aligned-two`, 681.26 | `release-openblas-aligned-two`, 681.26 | `arm-mixed1`, 291.63 | 2.33× | reduced precision |
| 159 × 4093 × 510 | `blasfeo`, 13.50 | `blasfeo`, 13.50 | `arm-mixed1`, 10.90 | 1.24× | reduced precision |
| 1793 × 1151 × 2779 | `cob-released`, 214.15 | `cob-released`, 214.15 | `arm-mixed1`, 89.82 | 2.40× | reduced precision |

The fastest native timing column includes reduced-precision methods. It describes the cost of the hardware path and carries the accuracy classification in the final column. The preregistered six-product primary is `mixed6`. `mixed6-bands`, `mixed9`, Intel’s fused AMX kernel, and Arm’s ACL-backed methods each have their own registered score.

| Contextual method | Warm paired ratio on measured layouts | Layouts measured | Cells outside gamma / absolute limit across bounded observations |
| --- | ---: | ---: | ---: |
| `mixed1` | — | 0/8 | 0 / 0 |
| `mixed3` | — | 0/8 | 0 / 0 |
| `mixed6` | — | 0/8 | 0 / 0 |
| `mixed6-bands` | — | 0/8 | 0 / 0 |
| `mixed9` | — | 0/8 | 0 / 0 |
| `fused6-amx` | — | 0/8 | 0 / 0 |
| `arm-mixed1` | 2.09× | 8/8 | 17,235,705 / 293,578,723 |
| `arm-mixed3` | 0.78× | 8/8 | 0 / 0 |
| `arm-mixed6` | 0.41× | 8/8 | 0 / 0 |
| `arm-mixed6-bands` | 0.39× | 8/8 | 0 / 0 |
| `arm-mixed9` | 0.30× | 8/8 | 0 / 0 |

FP32 field exclusions comprised `blasfeo` on 2/8.

The native adversarial panel independently compares actual output words and the released FP32 control to exact integer dot products. It tests 19 input families at two seeds, including finite cancellation, BF16 rounding boundaries, exact HK products, zero depth, range extremes and nonfinite behavior. Detailed per-method verdicts, failed input families and native versus rescue counts are retained in the evidence.

| Hardware method | Completed adversarial records / 38 | Normal inputs inside gamma | Exact HK dyadics | Range and special classes | Direct FP32 max/RMS quality |
| --- | ---: | --- | --- | --- | --- |
| `mixed1` | 38 | fail | pass | fail | fail |
| `mixed3` | 38 | fail | pass | pass | fail |
| `mixed6` | 38 | pass | pass | pass | pass |
| `mixed6-bands` | 38 | pass | pass | pass | pass |
| `mixed9` | 38 | pass | pass | pass | pass |
| `arm-mixed1` | 38 | fail | pass | fail | fail |
| `arm-mixed3` | 38 | fail | pass | pass | fail |
| `arm-mixed6` | 38 | pass | pass | pass | pass |
| `arm-mixed6-bands` | 38 | pass | pass | pass | pass |
| `arm-mixed9` | 38 | pass | pass | pass | pass |

The direct-quality column compares maximum and RMS absolute errors against ordinary released FP32 on the same inputs with the preregistered half-ULP allowance. It can reject a mixed method that passed every bounded large-matrix accuracy check. The source and per-case bit patterns let the offline verifier reconstruct this decision.

## Long-reduction numerical supplement

A separate untimed run on local Apple silicon under native AArch64 Linux checked 5 × 7 × 4096 and 7 × 9 × 8191 matrices against exact dot products. Two seeds and two distributions supplied eight matrices per method. On the matched direct-FP32 maximum/RMS screen, the six-term, widened-depth six-term and nine-term ACL implementations passed all eight. The one- and three-term implementations passed zero, although all 392 outputs per method were within the componentwise gamma bound. The worst matrix-relative RMS errors were 2.97×10⁻⁴ for both six-term schedules, 2.00×10⁻⁶ for nine terms and 7.93×10⁻³ for released FP32. These numerical ratios come from small-output views with long reductions; they do not enter the performance ranking. The supplement contains the exact reference integers, output words, identities, source, and a separate offline verifier. A second supplementary archive preserves the earlier untimed software and native instruction preflight, including 1,140 fixture/method records across all retained studies. Its SHA-256 is `e1e41ef4ebff25437c2339ef91f16378526e60eaec211f3b069259a879b0462a`.

## Measurement scope

Each release and library call overwrites initially poisoned FP32 output. Fresh processes use one pinned Linux thread, registered signed FP32 inputs, read-only parent A/B buffers and individually guarded C storage. The first call follows adapter initialization in a fresh process. The BF16 oneDNN wrapper creates its engine lazily inside that first call. The direct FP32 oneDNN adapter initializes its engine and stream before the timer. The second call receives the same inputs with its output re-poisoned. Its timed interval includes conversions, copying, dispatch, allocation, plans where applicable, multiplication and recombination. The prepared-plan comparator is identified separately. Single-host ratios from six observations carry noise; the package gives each pair, each first-call time, each seed block and leave-one-pair-out medians.

At 4096³, the six- and nine-term oneDNN wrappers allocate 320 MiB of component and FP32 temporary arrays before backend workspace. The three-call banded six-term wrapper adds 96 MiB. Six component products perform about 824.6 billion conventional floating-point operations. These counts follow from the source. The experiment times the whole call and does not apportion elapsed time among those operations.

The local field includes sequential vendor SGEMMs, strict oneDNN, two FastMMW cutoffs, released COB and its vendor-leaf competitors where qualified. Arm Compute Library provides the optional native BF16 engine. Direct Arm Compute Library FP32 SGEMM and native BLIS from the separate HK15 study were outside this panel. No independently runnable Cui–Liu implementation was available for a direct comparison. The two hosted CPUs and eight shapes cannot establish a worldwide ranking.

This run freezes COB release `f322a9ab58454762563b97323fdc5f29016cc39f` and benchmark `a23ab20dae16111c0604f92864bf6d072d6752f9`. Subsequent changes on main have separate provenance. [Production release](https://github.com/Milian0402/consequence_of_boredom_and_curiosity/tree/f322a9ab58454762563b97323fdc5f29016cc39f) · [Benchmark source](https://github.com/Milian0402/consequence_of_boredom_and_curiosity/tree/a23ab20dae16111c0604f92864bf6d072d6752f9/tools/world-rank/precision) · [Native run](https://github.com/Milian0402/consequence_of_boredom_and_curiosity/actions/runs/45717780617)

The ZIP contains the frozen native study and numerical oracle sources, raw paired timing/accuracy CSVs, native instruction receipts, hosted job identities and two offline replays. Run `python3 -B verify_all.py` from the extracted directory. The complete original hosted ZIPs can be checked using `python3 -B tools/bind.py hosts/x86_64 --original /path/to/original.zip` and the corresponding Arm command. Python 3.11 or later is required.
