"""Replay all retained FP32/mixed-precision observations on CPU, without BLAS or network."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from bind import verify_compact
from paired_evidence import verify
from accuracy_evidence import audit
from partial import partial
for row in (ROOT/'SHA256SUMS').read_text().splitlines():
    expected,name=row.split('  ',1)
    with (ROOT/name).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==expected,name
for host in ('x86_64','aarch64'):
    base=ROOT/'hosts'/host;verify_compact(base)
    published=json.loads((base/'paired.json').read_text())
    if published.get('incomplete'):
        assert partial(base/'raw',json.loads((base/'github.json').read_text()))==published
        print(host,'incomplete hosted evidence verified',published['coverage'])
        continue
    paired=verify(base/'raw');strong=audit(base/'raw',ROOT/'source')
    assert paired==json.loads((base/'paired.json').read_text()),host+' timing comparison'
    assert strong==json.loads((base/'adversarial.json').read_text()),host+' adversarial or native comparison'
    print(host,paired['host'],paired['coverage'])
